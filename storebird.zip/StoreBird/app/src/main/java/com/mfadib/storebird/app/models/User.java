package com.mfadib.storebird.app.models;

/**
 * Created by WIN 8.1 Pro on 12/15/2016.
 */

public class User {
    private int id;
    private String name;
    private String username;
    private String email;
    private String password;
    private String api_token;
    private String remember_token;
    private String created_at;
    private String updated_at;

    public User(int id, String name, String username, String email, String password, String api_token, String remember_token, String created_at, String updated_at) {
        this.id = id;
        this.name = name;
        this.username = username;
        this.email = email;
        this.password = password;
        this.api_token = api_token;
        this.remember_token = remember_token;
        this.created_at = created_at;
        this.updated_at = updated_at;
    }

    public int getId(){
        return id;
    }

    public void setId(int id){
        this.id = id;
    }

    public String getName(){
        return name;
    }

    public void setName(String name){
        this.name = name;
    }

    public String getUsername(){
        return username;
    }

    public void setUsername(String username){
        this.username = username;
    }

    public String getEmail(){
        return email;
    }

    public void setEmail(String email){
        this.email = email;
    }

    public String getPassword(){
        return password;
    }

    public void setPassword(String password){
        this.password = password;
    }

    public String getApi_token(){
        return api_token;
    }

    public void setApi_token(String api_token){
        this.api_token = api_token;
    }

    public String getRemember_token(){
        return remember_token;
    }

    public void setRemember_token(String remember_token){
        this.remember_token = remember_token;
    }

    public String getCreated_at(){
        return created_at;
    }

    public void setCreated_at(String created_at){
        this.created_at = created_at;
    }

    public String getUpdated_at(){
        return updated_at;
    }

    public void setUpdated_at(String updated_at){
        this.updated_at = updated_at;
    }

}
