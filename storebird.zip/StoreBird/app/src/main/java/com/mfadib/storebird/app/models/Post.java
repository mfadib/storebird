package com.mfadib.storebird.app.models;

/**
 * Created by WIN 8.1 Pro on 12/15/2016.
 */

public class Post {
    private int id;
    private String title;
    private String description;
    private String post_type;
    private int status;
    private String image;
    private String created_at;
    private String updated_at;

    public Post(int id, String title, String description, String post_type, int status, String image, String created_at, String updated_at) {
        this.id = id;
        this.title = title;
        this.description = description;
        this.post_type = post_type;
        this.status = status;
        this.image = image;
        this.created_at = created_at;
        this.updated_at = updated_at;
    }

    public int getId(){
        return id;
    }

    public void setId(int id){
        this.id = id;
    }

    public String getTitle(){
        return title;
    }

    public void setTitle(String title){
        this.title = title;
    }

    public String getDescription(){
        return description;
    }

    public void setDescription(String description){
        this.description = description;
    }

    public String getPost_type(){
        return post_type;
    }

    public void setPost_type(String post_type){
        this.post_type = post_type;
    }

    public int getStatus(){
        return status;
    }

    public void setStatus(int status){
        this.status = status;
    }

    public String getImage(){
        return image;
    }

    public void setImage(String image){
        this.image = image;
    }

    public String getCreated_at(){
        return created_at;
    }

    public void setCreated_at(String created_at){
        this.created_at = created_at;
    }

    public String getUpdated_at(){
        return updated_at;
    }

    public void setUpdated_at(String updated_at){
        this.updated_at = updated_at;
    }
}
