package com.mfadib.storebird.app.views;


import android.app.Activity;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v7.app.AlertDialog;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.mfadib.storebird.R;
import com.mfadib.storebird.app.Session;
import com.mfadib.storebird.app.Utility;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

/**
 * A simple {@link Fragment} subclass.
 */
public class FragmentAddPost extends Fragment {

    String BASE_URL = "http://storebird.mfadib.com/api/v1/";
    //    private RecyclerView recyclerView;
    private EditText etTitle,etDescription;
    private int REQUEST_CAMERA = 0, SELECT_FILE = 1;
    private Button btnImage, btnAdd;
    private Spinner spinPosttype;
    private Session session;
    private String userChoosenTask;
    private ImageView ivImage;
    private Uri selectedImageUri;
    private byte[] imgByte;
    public FragmentAddPost() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.add_newpost, container, false);
        session = new Session(view.getContext());
        if(session.loggedin()){
            etTitle = (EditText)view.findViewById(R.id.etTitle);
            etDescription = (EditText)view.findViewById(R.id.etDescription);
            spinPosttype = (Spinner)view.findViewById(R.id.spinPosttype);
            /* SPINNER INITIAL ITEM */

            ArrayAdapter<CharSequence> adSpiner = ArrayAdapter.createFromResource(view.getContext(),
                    R.array.post_type, android.R.layout.simple_spinner_item);
            adSpiner.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spinPosttype.setAdapter(adSpiner);

            /* END SPINNER INITIAL ITEM */

            btnAdd = (Button)view.findViewById(R.id.btnAdd);
            btnImage = (Button)view.findViewById(R.id.btnImage);
            ivImage = (ImageView)view.findViewById(R.id.imageView);
            btnImage.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
//                    selectImage();
                    galleryIntent();
                }
            });


            btnAdd.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    String[] data = {etTitle.getText().toString(),etDescription.getText().toString(),spinPosttype.getSelectedItem().toString()};
                    upload_forum(imgByte,data);
                }
            });
        }
        return view;
    }

    private void upload_forum(final byte[] path,final String[] data) {
        AsyncTask<Integer, Integer, Integer> task = new AsyncTask<Integer, Integer, Integer>() {
            ProgressDialog pd;

            @Override
            protected void onPreExecute() {
                pd = new ProgressDialog(getContext());
                pd.setTitle("Please wait...");
                pd.setMessage("Insert data to server");
                pd.setIndeterminate(true);
                pd.setCancelable(false);
                pd.show();
            }

            @Override
            protected Integer doInBackground(Integer... integers) {

                int result = 0;

                try{
                    MultipartBody requestBody = new MultipartBody.Builder()
                            .setType(MultipartBody.FORM)
                            .addFormDataPart("title",data[0])
                            .addFormDataPart("description",data[1])
                            .addFormDataPart("post_type",data[2])
                            .addFormDataPart("status","1")
                            .addFormDataPart("image","image_", RequestBody.create(MultipartBody.FORM,path))
                            .build();
                    Log.d("setting body request","OK");
                    OkHttpClient com = new OkHttpClient();
                    Request req = new Request.Builder()
                            .url(BASE_URL + "post")
                            .post(requestBody)
                            .build();
                    Log.d("Request to server","OK");
                    try {
                        Response resp = com.newCall(req).execute();
                        JSONObject jsonObject = new JSONObject(resp.body().string());
                        Log.d("Response",String.valueOf(resp));
                        boolean status = jsonObject.getBoolean("status");
                        Log.d("Response From server",String.valueOf(status));
                        String msg = jsonObject.getString("message");
                        if(status == true){
                            result = 1;
                        }else{
                            result= 0;
                        }
                    } catch (IOException e) {
                        e.printStackTrace();
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                } catch (Exception e) {
                    result = 0;
                }

                return result;
            }

            @Override
            protected void onPostExecute(Integer res) {
                if(res == 1){
                    Toast.makeText(getContext(),"Data post berhasil ditambah",Toast.LENGTH_LONG).show();
                    try{
                        ((FragmentActivity) getContext())
                                .getSupportFragmentManager().beginTransaction()
                                .replace(R.id.fragment_main, FragmentPost.class.newInstance()).commit();
                    }catch (Exception e){
                        e.printStackTrace();
                    }
                }else{
                    Toast.makeText(getContext(),"Gagal saat memasukan data",Toast.LENGTH_LONG).show();
                }
                pd.dismiss();
            }
        };

        task.execute();
    }

    private File getOutputMediafile(int type) {
        File mediaStorageDir = new File(Environment.getExternalStoragePublicDirectory(
                Environment.DIRECTORY_PICTURES), getResources().getString(R.string.app_name)
        );
        if (!mediaStorageDir.exists()) {
            if (!mediaStorageDir.mkdirs()) {
                return null;
            }
        }
        String timeStamp = new SimpleDateFormat("yyyyHHdd_HHmmss").format(new Date());
        File mediaFile;
        if (type == 1) {
            mediaFile = new File(mediaStorageDir.getPath() + File.separator + "IMG_" + timeStamp + ".png");
        } else {
            return null;
        }

        return mediaFile;
    }

    private void selectImage() {
        final CharSequence[] items = { "Ambil Foto", "Pilih dari galeri", "Batal" };
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setTitle("Tambah Foto!");
        builder.setItems(items, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int item) {
                boolean result = Utility.checkPermission(getActivity());
                if (items[item].equals("Ambil Foto")) {
                    userChoosenTask="Ambil Foto";
                    if(result)
                        cameraIntent();
                } else if (items[item].equals("Pilih dari galeri")) {
                    userChoosenTask="Pilih dari galeri";
                    if(result)
                        galleryIntent();
                } else if (items[item].equals("Batal")) {
                    dialog.dismiss();
                }
            }
        });
        builder.show();
    }

    private void setPhoto(Bitmap bitmap) {
        try {
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, baos);

            byte[] byteArrayImage = baos.toByteArray();
            imgByte = byteArrayImage;
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    //
    private void cameraIntent()
    {
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        File file = getOutputMediafile(1);
        selectedImageUri = Uri.fromFile(file);
        intent.putExtra(MediaStore.EXTRA_OUTPUT,selectedImageUri);
        startActivityForResult(intent,REQUEST_CAMERA);
    }
    private void galleryIntent()
    {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);//
        File file = getOutputMediafile(1);
        selectedImageUri = Uri.fromFile(file);
        intent.putExtra(MediaStore.EXTRA_OUTPUT,selectedImageUri);
        startActivityForResult(Intent.createChooser(intent, "Select File"),SELECT_FILE);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == SELECT_FILE) {
                onSelectFromGalleryResult(data);
            }else if (requestCode == REQUEST_CAMERA) {
                onCaptureImageResult(data);
            }
        }
    }
    @SuppressWarnings("deprecation")
    private void onSelectFromGalleryResult(Intent data) {
        Bitmap bm=null;
        if (data != null) {
            try {
                bm = MediaStore.Images.Media.getBitmap(getActivity().getContentResolver(), data.getData());
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        setPhoto(bm);
        btnAdd.setVisibility(View.VISIBLE);
        btnAdd.setClickable(true);
        ivImage.setVisibility(View.VISIBLE);
        ivImage.setImageBitmap(bm);
    }

    private void onCaptureImageResult(Intent data) {
        Bitmap thumbnail = (Bitmap) data.getExtras().get("data");
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        thumbnail.compress(Bitmap.CompressFormat.JPEG, 90, bytes);

        File destination = new File(Environment.getExternalStorageDirectory(),
                System.currentTimeMillis() + ".jpg");

        FileOutputStream fo;
        try {
            destination.createNewFile();
            fo = new FileOutputStream(destination);
            fo.write(bytes.toByteArray());
            fo.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        setPhoto(thumbnail);
        btnAdd.setVisibility(View.VISIBLE);
        btnAdd.setClickable(true);
        ivImage.setVisibility(View.VISIBLE);
        ivImage.setImageBitmap(thumbnail);
    }



    /* Other code for permission */
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        switch (requestCode) {
            case Utility.MY_PERMISSIONS_REQUEST_READ_EXTERNAL_STORAGE:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    if(userChoosenTask.equals("Ambil Foto"))
                        cameraIntent();
                    else if(userChoosenTask.equals("Pilih dari galeri"))
                        galleryIntent();
                } else {
                    //code for deny
                }
                break;
        }
    }

}
