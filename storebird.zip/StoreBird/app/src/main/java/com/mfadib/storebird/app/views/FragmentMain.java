package com.mfadib.storebird.app.views;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.mfadib.storebird.R;
import com.mfadib.storebird.app.adapters.MenuAdapter;

public class FragmentMain extends Fragment {
    RecyclerView recyclerView;
    RecyclerView.LayoutManager layoutManager;
    RecyclerView.Adapter adapter;

    public FragmentMain() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the profile_user for this fragment
        View rootView =  inflater.inflate(R.layout.fragment_main, container, false);
//        setRetainInstance(true);

        recyclerView = (RecyclerView)rootView.findViewById(R.id.recycler_view);
//        recyclerView.setHasFixedSize(true);

        layoutManager = new GridLayoutManager(getActivity(),3);
        recyclerView.setLayoutManager(layoutManager);

        adapter = new MenuAdapter();
        recyclerView.setAdapter(adapter);
        return rootView;
    }

}
