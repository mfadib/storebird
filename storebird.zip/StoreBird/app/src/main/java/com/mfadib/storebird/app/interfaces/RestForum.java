package com.mfadib.storebird.app.interfaces;

import com.google.gson.JsonElement;
import com.mfadib.storebird.app.models.Forum;
import com.mfadib.storebird.app.responses.ResponseForum;

import java.util.List;

import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.http.DELETE;
import retrofit2.http.GET;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.PUT;
import retrofit2.http.Part;
import retrofit2.http.Path;

/**
 * Created by WIN 8.1 Pro on 12/20/2016.
 */

public interface RestForum {
    @GET("forums")
//    Call<Forum> all(Callback<JsonElement> callback);
    Call<ResponseForum> all();

    @GET("forum/{id}")
    Call<Forum> detail(@Path("id") String id,Callback<JsonElement> callback);

    @Multipart
    @POST("forum")
    Call<Forum> insert(@Part("id") RequestBody id,
                       @Part("user_id") RequestBody user_id,
                       @Part("title") RequestBody title,
                       @Part("description") RequestBody description,
                       @Part("image") MultipartBody.Part image,
                       @Part("updated_at") RequestBody updated_at,
                       @Part("created_at") RequestBody created_at,
                       Callback<Response> callback);


    @Multipart
    @PUT("forum/{id}")
    Call<Forum> update(@Path("id") String id,
                       @Part("user_id") RequestBody user_id,
                       @Part("title") RequestBody title,
                       @Part("description") RequestBody description,
                       @Part("image") MultipartBody.Part image,
                       @Part("updated_at") RequestBody updated_at,
                       @Part("created_at") RequestBody created_at,
                       Callback<Response> callback);

    @DELETE("forum/{id}")
    Call<Forum> delete(@Path("id") String id,Callback<Response> callback);

}
