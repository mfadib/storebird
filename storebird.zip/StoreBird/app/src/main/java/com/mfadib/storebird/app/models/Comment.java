package com.mfadib.storebird.app.models;

/**
 * Created by WIN 8.1 Pro on 12/15/2016.
 */

public class Comment {
    private int id;
    private int user_id;
    private int relation_id;
    private int comment_parent;
    private String comment_type;
    private String comment;
    private String username;
    private String status;
    private String created_at;
    private String updated_at;

    public Comment(int id, int user_id, int relation_id,String username, String comment_type, int comment_parent, String comment, String status, String created_at, String updated_at) {
        this.id = id;
        this.user_id = user_id;
        this.relation_id = relation_id;
        this.comment_parent = comment_parent;
        this.comment = comment;
        this.comment_type = comment_type;
        this.status = status;
        this.created_at = created_at;
        this.updated_at = updated_at;
        this.username = username;
    }

    public String getComment_type() {
        return comment_type;
    }

    public void setComment_type(String comment_type) {
        this.comment_type = comment_type;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public int getId(){
        return id;
    }

    public void setId(int id){
        this.id = id;
    }

    public int getUser_id(){
        return user_id;
    }

    public void setUser_id(int user_id){
        this.user_id = user_id;
    }

    public int getRelation_id(){
        return relation_id;
    }

    public void setRelation_id(int forum_id){
        this.relation_id = relation_id;
    }

    public int getComment_parent(){
        return comment_parent;
    }

    public void setComment_parent(int comment_parent){
        this.comment_parent = comment_parent;
    }

    public String getComment(){
        return comment;
    }

    public void setComment(String comment){
        this.comment = comment;
    }

    public String getStatus(){
        return status;
    }

    public void setStatus(String status){
        this.status = status;
    }

    public String getCreated_at(){
        return created_at;
    }

    public void setCreated_at(String created_at){
        this.created_at = created_at;
    }

    public String getUpdated_at(){
        return updated_at;
    }

    public void setUpdated_at(String updated_at){
        this.updated_at = updated_at;
    }
}
