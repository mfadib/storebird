package com.mfadib.storebird.app.views;


import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.mfadib.storebird.R;
import com.mfadib.storebird.app.Session;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;

import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

/**
 * A simple {@link Fragment} subclass.
 */
public class FragmentRegister extends Fragment {

    String BASE_URL = "http://storebird.mfadib.com/api/v1/";
    private EditText etName;
    private EditText etUsername;
    private EditText etEmail;
    private EditText etPassword;
    private Button btnRegister;
    private TextView tvLogin;
    private String user_type = "user";
    private Session session;

    public FragmentRegister() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             final Bundle savedInstanceState) {
        // Inflate the profile_user for this fragment
        View view =  inflater.inflate(R.layout.fragment_register, container, false);
//        setRetainInstance(true);

        /* Initialization items */
        etName= (EditText)view.findViewById(R.id.etName);
        etUsername= (EditText)view.findViewById(R.id.etUsername);
        etEmail = (EditText)view.findViewById(R.id.etEmail);
        etPassword = (EditText)view.findViewById(R.id.etPassword);
        btnRegister = (Button)view.findViewById(R.id.btnRegister);
        tvLogin = (TextView)view.findViewById(R.id.tvLogin);

        session = new Session(view.getContext());
        if(session.loggedin()){
            try{
                if(savedInstanceState == null) {
                    ((FragmentActivity) getContext())
                            .getSupportFragmentManager().beginTransaction()
                            .replace(R.id.fragment_main, FragmentUser.class.newInstance()).commit();
                }

            }catch (Exception e){
                e.printStackTrace();
            }
        }

        tvLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try{
                    if(savedInstanceState == null) {
                        ((FragmentActivity) getContext())
                                .getSupportFragmentManager().beginTransaction()
                                .replace(R.id.fragment_main, FragmentLogin.class.newInstance()).commit();
                    }
                }catch (Exception e){
                    e.printStackTrace();
                }
            }
        });

        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String[] data = {
                        etName.getText().toString(),
                        etUsername.getText().toString(),
                        etEmail.getText().toString(),
                        etPassword.getText().toString(),
                        "user"
                };
                register(data);
            }
        });

        return view;
    }


    private void register(final String[] data) {
        AsyncTask<Integer, Integer, Integer> task = new AsyncTask<Integer, Integer, Integer>() {
            ProgressDialog pd;
            private String name,username,email,password,user_type;

            @Override
            protected void onPreExecute() {
                pd = new ProgressDialog(getContext());
                pd.setTitle("Please wait...");
                pd.setMessage("processing insert data to server");
                pd.setIndeterminate(true);
                pd.setCancelable(false);
                pd.show();
            }

            @Override
            protected Integer doInBackground(Integer... integers) {
                int result = 0;
                FormBody.Builder formBulider = new FormBody.Builder()
                        .add("name",data[0])
                        .add("username",data[1])
                        .add("email",data[2])
                        .add("password", data[3])
                        .add("user_type",data[4]);
                RequestBody formBody = formBulider.build();

                OkHttpClient com = new OkHttpClient();
                Request req = new Request.Builder()
                        .url(BASE_URL + "user")
                        .post(formBody)
                        .build();
                try {
                    Response resp = com.newCall(req).execute();
                    JSONObject jsonObject = new JSONObject(resp.body().string());
                    boolean status = jsonObject.getBoolean("status");
                    String msg = jsonObject.getString("message");
                    if(status == true){
                        result = 1;
                    }else{
                        result= 0;
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                return result;
            }

            @Override
            protected void onPostExecute(Integer res) {
                if(res == 1){
                    Toast.makeText(getContext(),"Data anda berhasil dimasukan, silahkan login",Toast.LENGTH_LONG).show();
                    try{
                        ((FragmentActivity) getContext())
                            .getSupportFragmentManager().beginTransaction()
                            .replace(R.id.fragment_main, FragmentLogin.class.newInstance()).commit();
                    }catch (Exception e){
                        e.printStackTrace();
                    }
                }else{
                    Toast.makeText(getContext(),"Gagal saat mendaftar",Toast.LENGTH_LONG).show();
                }
                pd.dismiss();
            }
        };

        task.execute();
    }

}
