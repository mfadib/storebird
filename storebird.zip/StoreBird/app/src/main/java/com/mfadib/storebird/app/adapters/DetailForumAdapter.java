package com.mfadib.storebird.app.adapters;

import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.mfadib.storebird.R;
import com.mfadib.storebird.app.models.Forum;
import com.mfadib.storebird.app.views.FragmentForumDetail;

import java.util.List;

/**
 * Created by WIN 8.1 Pro on 12/24/2016.
 */

public class DetailForumAdapter extends RecyclerView.Adapter<DetailForumAdapter.ViewHolder> {

    private Context context;
    private List<Forum> forums;

    public DetailForumAdapter(Context context, List<Forum> forums) {
        super();
        this.context = context;
        this.forums = forums;
    }

    @Override
    public DetailForumAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v  = LayoutInflater.from(parent.getContext()).inflate(R.layout.data_listview, parent, false);
        DetailForumAdapter.ViewHolder viewHolder = new DetailForumAdapter.ViewHolder(v);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(DetailForumAdapter.ViewHolder holder, int position) {
        Forum i = forums.get(position);
        holder.id.setText(String.valueOf(i.getId()));
        holder.title.setText(i.getTitle());
        holder.description.setText(i.getDescription());
        holder.created.setText(i.getUpdated_at());
        if((i.getImage() == null) || (i.getImage() == "")){
            Glide.with(context).load("http://storebird.mfadib.com/images/notfound.jpg")
                    .diskCacheStrategy(DiskCacheStrategy.SOURCE).into(holder.image);
        }else{
            Glide.with(context).load("http://storebird.mfadib.com/images/"+i.getImage())
                    .diskCacheStrategy(DiskCacheStrategy.SOURCE).into(holder.image);
        }
    }

    @Override
    public int getItemCount() {
        return forums.size();
    }


    public class ViewHolder extends RecyclerView.ViewHolder{
        public TextView id;
        public TextView title;
        public TextView description;
        public TextView created;
        public ImageView image;
        public ViewHolder(final View viewHolder){
            super(viewHolder);
            id = (TextView)viewHolder.findViewById(R.id.tvId);
            title = (TextView)viewHolder.findViewById(R.id.tvTitle);
            description = (TextView)viewHolder.findViewById(R.id.tvDescription);
            image = (ImageView)viewHolder.findViewById(R.id.img_thumbnail);
            created = (TextView)viewHolder.findViewById(R.id.tvEtc);
        }
    }

    @Override
    public void onAttachedToRecyclerView(RecyclerView recyclerView){
        super.onAttachedToRecyclerView(recyclerView);
    }
}
