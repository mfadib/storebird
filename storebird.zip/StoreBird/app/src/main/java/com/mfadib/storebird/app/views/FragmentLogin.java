package com.mfadib.storebird.app.views;

import android.app.ProgressDialog;
import android.content.Context;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.StrictMode;
import android.support.design.widget.NavigationView;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.mfadib.storebird.R;
import com.mfadib.storebird.app.Session;
import com.mfadib.storebird.app.controllers.MainActivity;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;

import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class FragmentLogin extends Fragment {

    String BASE_URL = "http://storebird.mfadib.com/api/v1/";
    private Session session;
    private EditText etEmail;
    private EditText etPassword;
    private Button btnLogin;
    private TextView tvRegister;
//    private NavigationView navigationView;
    public FragmentLogin() {
        // Required empty public constructor
    }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             final Bundle savedInstanceState) {
        // Inflate the profile_user for this fragment
        View view = inflater.inflate(R.layout.fragment_login, container, false);

        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);

//        navigationView = (NavigationView)view.findViewById(R.id.nav_view);
//        setRetainInstance(true);
        session = new Session(view.getContext());
        if(session.loggedin()){
            try {
                if(savedInstanceState == null) {
                    ((FragmentActivity) getContext())
                            .getSupportFragmentManager().beginTransaction()
                            .replace(R.id.fragment_main, FragmentUser.class.newInstance()).commit();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        etEmail = (EditText)view.findViewById(R.id.etEmail);
        etPassword = (EditText)view.findViewById(R.id.etPassword);
        btnLogin = (Button)view.findViewById(R.id.btnLogin);
        tvRegister = (TextView)view.findViewById(R.id.tvRegister);
        tvRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try{
                    if(savedInstanceState == null) {
                        ((FragmentActivity) getContext())
                                .getSupportFragmentManager().beginTransaction()
                                .replace(R.id.fragment_main, FragmentRegister.class.newInstance()).commit();
                    }

                }catch (Exception e){
                    e.printStackTrace();
                }
            }
        });

        btnLogin.setOnClickListener(new View.OnClickListener() {
            private String res;
            @Override
            public void onClick(View view) {
                login(etEmail.getText().toString(),etPassword.getText().toString());
//                Toast.makeText(getContext(),"this result "+res.toString(),Toast.LENGTH_LONG);
//                Log.d("Result request :",res.toString());
            }
        });


        return view;
    }

    private void login(final String email, final String password) {
        AsyncTask<Integer, Integer, Integer> task = new AsyncTask<Integer, Integer, Integer>() {
            ProgressDialog pd;

            @Override
            protected void onPreExecute() {
                pd = new ProgressDialog(getContext());
                pd.setTitle("Please wait...");
                pd.setMessage("Check data from server");
                pd.setIndeterminate(true);
                pd.setCancelable(false);
                pd.show();
            }

            @Override
            protected Integer doInBackground(Integer... integers) {
                int result = 0;
                FormBody.Builder formBulider = new FormBody.Builder()
                        .add("email", email)
                        .add("password", password);
                RequestBody formBody = formBulider.build();

                OkHttpClient com = new OkHttpClient();
                Request req = new Request.Builder()
                        .url(BASE_URL + "auth/login")
                        .post(formBody)
                        .build();
                try {
                    Response resp = com.newCall(req).execute();
                    JSONObject jsonObject = new JSONObject(resp.body().string());
                    boolean status = jsonObject.getBoolean("status");
                    String msg = jsonObject.getString("message");
                    if(status == true){
                        JSONArray jsonArray = jsonObject.getJSONArray("data");
                        if(jsonArray.length() == 1){
                            for(int i = 0; i<jsonArray.length();i++){
                                JSONObject obj = jsonArray.getJSONObject(i);
                                session.setLoggedin(true,obj.getInt("id"),obj.getString("api_token").toString(),obj.getString("user_type").toString());
                                result = 1;
                            }
                        }else{
                            result= 0;
                        }
                    }else{
                        result= 0;
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                return result;
            }

            @Override
            protected void onPostExecute(Integer res) {
                if(res == 1){
                    Toast.makeText(getContext(),"Selamat datang disistem storebird",Toast.LENGTH_LONG).show();
                    try{
                        ((FragmentActivity) getContext())
                                .getSupportFragmentManager().beginTransaction()
                                .replace(R.id.fragment_main, FragmentMain.class.newInstance()).commit();
                    }catch (Exception e){
                        e.printStackTrace();
                    }
                }else{
                    Toast.makeText(getContext(),"Email atau password Anda salah",Toast.LENGTH_LONG).show();
                }
                pd.dismiss();
            }
        };

        task.execute();
    }
}
