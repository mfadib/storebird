package com.mfadib.storebird.app.views;


import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.mfadib.storebird.R;
import com.mfadib.storebird.app.Session;
import com.mfadib.storebird.app.adapters.ProfileAdapter;
import com.mfadib.storebird.app.models.User;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

/**
 * A simple {@link Fragment} subclass.
 */
public class FragmentProfile extends Fragment {

    String BASE_URL = "http://storebird.mfadib.com/api/v1/";
    private Session session;
    private RecyclerView recyclerView;
    private GridLayoutManager gridLayoutManager;
    private ProfileAdapter adapter;
    private List<User> dataList;
//    private EditText etName, etUsername, etEmail, etOldPassword, etNewPassword, etConfrim;
//    private Button btnSave;
    public FragmentProfile() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_main, container, false);
        dataList = new ArrayList<>();
        session = new Session(view.getContext());
        load_data_from_server(session.getId());

        recyclerView = (RecyclerView)view.findViewById(R.id.recycler_view);
        gridLayoutManager = new GridLayoutManager(getActivity(),1);
        recyclerView.setLayoutManager(gridLayoutManager);

        adapter = new ProfileAdapter(getContext(),dataList);
        recyclerView.setAdapter(adapter);
//
//        etName = (EditText)view.findViewById(R.id.etName);
//        etUsername= (EditText)view.findViewById(R.id.etUsername);
//        etEmail = (EditText)view.findViewById(R.id.etEmail);
//        etOldPassword = (EditText)view.findViewById(R.id.etOldPassword);
//        etNewPassword = (EditText)view.findViewById(R.id.etNewPassword);
//        etConfrim = (EditText)view.findViewById(R.id.etConfirm);
//        btnSave = (Button)view.findViewById(R.id.btnSave);
//
//        btnSave.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Toast.makeText(view.getContext(),"Your name "+etName.getText().toString()+" and your username "+etUsername.getText().toString()+" and your email"+etEmail.getText().toString(),Toast.LENGTH_LONG).show();
//
//            }
//        });

        return view;
    }

    private void load_data_from_server(final int id) {

        AsyncTask<Integer, Void, Void> task = new AsyncTask<Integer, Void, Void>() {
            ProgressDialog pd;
            @Override
            protected void onPreExecute(){
                pd = new ProgressDialog(getContext());
                pd.setTitle("Please wait...");
                pd.setMessage("Get your data...");
                pd.setIndeterminate(true);
                pd.setCancelable(false);
                pd.show();
            }
            @Override
            protected Void doInBackground(Integer... integers) {
                OkHttpClient client = new OkHttpClient();
                Request request = new Request.Builder()
                        .url(BASE_URL+"user/"+id).build();
//                RestForum api = client
                try {
                    Log.d("Request Server",BASE_URL+"user/"+id);
                    Response response = client.newCall(request).execute();
                    JSONObject jsonObject = new JSONObject(response.body().string());
                    if(jsonObject.getBoolean("status") == true){
                        JSONArray jsonArray = jsonObject.getJSONArray("data");
                        Log.d("Data Result",jsonArray.toString());
                        for(int i = 0; i<jsonArray.length();i++){
                            JSONObject obj = jsonArray.getJSONObject(i);
                            User users = new User(obj.getInt("id"),obj.getString("name"),obj.getString("username"),
                                    obj.getString("email"),"",
                                    "","",
                                    obj.getString("created_at"),obj.getString("updated_at"));
                            dataList.add(users);
                        }
                    }else{
                        Toast.makeText(getContext(),jsonObject.getString("message"),Toast.LENGTH_LONG).show();
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                } catch (JSONException e) {
                    e.printStackTrace();
                }

                return null;
            }

            @Override
            protected void onPostExecute(Void aVoid){
                adapter.notifyDataSetChanged();
                pd.dismiss();
            }
        };

        task.execute();
    }

}
