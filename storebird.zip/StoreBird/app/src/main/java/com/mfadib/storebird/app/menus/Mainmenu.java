package com.mfadib.storebird.app.menus;

/**
 * Created by WIN 8.1 Pro on 12/18/2016.
 */

public class Mainmenu {
    private String name;
    private int imgThumbnail;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getImgThumbnail() {
        return imgThumbnail;
    }

    public void setImgThumbnail(int imgThumbnail) {
        this.imgThumbnail = imgThumbnail;
    }
}
