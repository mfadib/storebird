package com.mfadib.storebird.app.interfaces;

/**
 * Created by WIN 8.1 Pro on 12/20/2016.
 */

public interface RestPost {
}
