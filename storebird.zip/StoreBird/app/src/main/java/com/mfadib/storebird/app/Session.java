package com.mfadib.storebird.app;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * Created by WIN 8.1 Pro on 12/23/2016.
 */

public class Session {
    SharedPreferences prefs;
    SharedPreferences.Editor editor;
    Context ctx;

    public Session(Context ctx){
        this.ctx = ctx;
        prefs = ctx.getSharedPreferences("session_storebird",Context.MODE_PRIVATE);
        editor = prefs.edit();
    }

    public void setLoggedin(boolean loggedin,int id,String api_token,String user_type){
        editor.putBoolean("loggedInmode",loggedin);
        editor.putString("api_token",api_token);
        editor.putString("user_type",user_type);
        editor.putInt("id",id);
        editor.commit();
    }

    public boolean loggedin(){
        return prefs.getBoolean("loggedInmode",false);
    }

    public int getId(){
        return prefs.getInt("id",0);
    }

    public String getUsertype(){
        return prefs.getString("user_type",null);
    }

    public String getApitoken(){
        return prefs.getString("api_token",null);
    }
}
