package com.mfadib.storebird.app.adapters;

import android.content.Context;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.mfadib.storebird.R;
import com.mfadib.storebird.app.models.Comment;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by WIN 8.1 Pro on 12/24/2016.
 */

public class CommentAdapter extends RecyclerView.Adapter<CommentAdapter.ViewHolder> {

    private Context context;
    private List<Comment> comments;

    public CommentAdapter(Context context, List<Comment> comments) {
        super();
        this.context = context;
        this.comments = comments;
    }

    @Override
    public CommentAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v  = LayoutInflater.from(parent.getContext()).inflate(R.layout.data_comments, parent, false);
        CommentAdapter.ViewHolder viewHolder = new CommentAdapter.ViewHolder(v);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(CommentAdapter.ViewHolder holder, int position) {
        Comment i = comments.get(position);
        holder.username.setText(i.getUsername());
        holder.comment.setText(i.getComment());
        holder.created.setText(i.getUpdated_at());
    }

    @Override
    public int getItemCount() {
        return comments.size();
    }


    public class ViewHolder extends RecyclerView.ViewHolder{
        public TextView username;
        public TextView comment;
        public TextView created;
        public ViewHolder(final View viewHolder){
            super(viewHolder);
            username = (TextView)viewHolder.findViewById(R.id.tvUsername);
            comment = (TextView)viewHolder.findViewById(R.id.tvComment);
            created = (TextView)viewHolder.findViewById(R.id.tvCreated);
        }
    }

    @Override
    public void onAttachedToRecyclerView(RecyclerView recyclerView){
        super.onAttachedToRecyclerView(recyclerView);
    }
}
