package com.mfadib.storebird.app.adapters;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.AsyncTask;
import android.os.StrictMode;
import android.support.v4.app.FragmentActivity;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.mfadib.storebird.R;
import com.mfadib.storebird.app.models.Bird;
import com.mfadib.storebird.app.views.FragmentStore;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.List;

import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

/**
 * Created by WIN 8.1 Pro on 1/3/2017.
 */

public class BirdEditAdapter extends RecyclerView.Adapter<BirdEditAdapter.ViewHolder>  {

    private Context context;
    private List<Bird> birds;
    String BASE_URL = "http://storebird.mfadib.com/api/v1/";

    public BirdEditAdapter(Context context, List<Bird> birds) {
        super();
        this.context = context;
        this.birds = birds;
    }

    @Override
    public BirdEditAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v  = LayoutInflater.from(parent.getContext()).inflate(R.layout.edit_bird, parent, false);
        BirdEditAdapter.ViewHolder viewHolder = new BirdEditAdapter.ViewHolder(v);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(BirdEditAdapter.ViewHolder holder, int position) {
        Bird i = birds.get(position);
        int p;
        holder.id = String.valueOf(i.getId());
        holder.etTitle.setText(i.getTitle());
        holder.etDescription.setText(i.getDescription());
        holder.etInfo.setText(i.getInfo());
        holder.etPrice.setText(i.getPrice());
    }

    @Override
    public int getItemCount() {
        return birds.size();
    }


    public class ViewHolder extends RecyclerView.ViewHolder{
        public String id;
        public EditText etTitle,etDescription,etInfo,etPrice;
        public Button btnEdit;
        public ViewHolder(final View viewHolder){
            super(viewHolder);
            etTitle = (EditText)viewHolder.findViewById(R.id.etTitle);
            etDescription = (EditText)viewHolder.findViewById(R.id.etDescription);
            etInfo = (EditText)viewHolder.findViewById(R.id.etInfo);
            etPrice = (EditText)viewHolder.findViewById(R.id.etPrice);

            btnEdit = (Button)viewHolder.findViewById(R.id.btnEdit);

            btnEdit.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    String[] data = {
                        etTitle.getText().toString(),
                        etDescription.getText().toString(),
                        etInfo.getText().toString(),
                        etPrice.getText().toString()};
                    editContent(id,data);
                }
            });
        }
    }

    public void editContent(final String id, final String[] data){

        AsyncTask<Integer, Integer, Integer> task = new AsyncTask<Integer, Integer, Integer>() {
            ProgressDialog pd;

            @Override
            protected void onPreExecute() {
                pd = new ProgressDialog(context);
                pd.setTitle("Please wait...");
                pd.setMessage("Updating data to server");
                pd.setIndeterminate(true);
                pd.setCancelable(false);
                pd.show();
            }

            @Override
            protected Integer doInBackground(Integer... integers) {

                int result = 0;

                try{
                    StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
                    StrictMode.setThreadPolicy(policy);

                    FormBody.Builder formBulider = new FormBody.Builder()
                            .add("title", String.valueOf(data[0]))
                            .add("description", String.valueOf(data[1]))
                            .add("info", String.valueOf(data[2]))
                            .add("price", String.valueOf(data[3]));
                    RequestBody formBody = formBulider.build();

                    OkHttpClient com = new OkHttpClient();
                    Request req = new Request.Builder()
                            .url(BASE_URL + "bird/"+id)
                            .put(formBody)
                            .build();
                    try {
                        Response resp = com.newCall(req).execute();
                        JSONObject jsonObject = new JSONObject(resp.body().string());
                        boolean status = jsonObject.getBoolean("status");
                        Log.d("Response From server",String.valueOf(status));
                        if(status == true){
                            result = 1;
                        }else{
                            result= 0;
                        }
                    } catch (IOException e) {
                        e.printStackTrace();
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                } catch (Exception e) {
                    result = 0;
                }

                return result;
            }

            @Override
            protected void onPostExecute(Integer res) {
                if(res == 1){
                    Toast.makeText(context,"Data berhasil diubah",Toast.LENGTH_LONG).show();
                    try{
                        ((FragmentActivity) context)
                                .getSupportFragmentManager().beginTransaction()
                                .replace(R.id.fragment_main, FragmentStore.class.newInstance()).commit();
                    }catch (Exception e){
                        e.printStackTrace();
                    }
                }else{
                    Toast.makeText(context,"Gagal saat mengubah data",Toast.LENGTH_LONG).show();
                }
                pd.dismiss();
            }
        };

        task.execute();
    }

    @Override
    public void onAttachedToRecyclerView(RecyclerView recyclerView){
        super.onAttachedToRecyclerView(recyclerView);
    }
}
