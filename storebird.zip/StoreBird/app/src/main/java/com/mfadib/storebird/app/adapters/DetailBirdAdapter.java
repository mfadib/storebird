package com.mfadib.storebird.app.adapters;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.mfadib.storebird.R;
import com.mfadib.storebird.app.models.Bird;

import java.util.List;

/**
 * Created by WIN 8.1 Pro on 1/3/2017.
 */

public class DetailBirdAdapter extends RecyclerView.Adapter<DetailBirdAdapter.ViewHolder>  {

    private Context context;
    private List<Bird> birds;

    public DetailBirdAdapter(Context context, List<Bird> birds) {
        super();
        this.context = context;
        this.birds = birds;
    }

    @Override
    public DetailBirdAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v  = LayoutInflater.from(parent.getContext()).inflate(R.layout.data_listview, parent, false);
        DetailBirdAdapter.ViewHolder viewHolder = new DetailBirdAdapter.ViewHolder(v);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(DetailBirdAdapter.ViewHolder holder, int position) {
        Bird i = birds.get(position);
        holder.info.setVisibility(View.VISIBLE);
        holder.coma.setVisibility(View.VISIBLE);

        holder.id.setText(String.valueOf(i.getId()));
        holder.title.setText(i.getTitle());
        holder.description.setText(i.getDescription());
        holder.info.setText(i.getInfo());
        holder.price.setText(i.getPrice());
        holder.rp.setText("Rp.");
        holder.coma.setText(" ");
//        holder.created.setText(i.getUpdated_at());
        if((i.getPhoto() == null) || (i.getPhoto() == "")){
            Glide.with(context).load("http://storebird.mfadib.com/images/notfound.jpg")
                    .diskCacheStrategy(DiskCacheStrategy.SOURCE).into(holder.image);
        }else{
            Glide.with(context).load("http://storebird.mfadib.com/images/"+i.getPhoto())
                    .diskCacheStrategy(DiskCacheStrategy.SOURCE).into(holder.image);
        }
    }

    @Override
    public int getItemCount() {
        return birds.size();
    }


    public class ViewHolder extends RecyclerView.ViewHolder{
        public TextView id,title,description,info,price,rp,coma;
        public ImageView image;
        public ViewHolder(final View viewHolder){
            super(viewHolder);
            id = (TextView)viewHolder.findViewById(R.id.tvId);
            title = (TextView)viewHolder.findViewById(R.id.tvTitle);
            description = (TextView)viewHolder.findViewById(R.id.tvDescription);
            info = (TextView)viewHolder.findViewById(R.id.tvInfo);
            image = (ImageView)viewHolder.findViewById(R.id.img_thumbnail);
            price = (TextView)viewHolder.findViewById(R.id.tvEtc);
            rp = (TextView)viewHolder.findViewById(R.id.tvEtc2);
            coma = (TextView)viewHolder.findViewById(R.id.tvDash);
            coma.setVisibility(View.VISIBLE);
            info.setVisibility(View.VISIBLE);
        }
    }

    @Override
    public void onAttachedToRecyclerView(RecyclerView recyclerView){
        super.onAttachedToRecyclerView(recyclerView);
    }
}
