package com.mfadib.storebird.app.models;

/**
 * Created by WIN 8.1 Pro on 12/22/2016.
 */

public class Auth {
    public int id;
    public String name;
    public String username;
    public String email;
    public String api_token;
    public boolean loggedin = false;

    public Auth(int id, String name, String username, String email, String api_token,boolean loggedin) {
        this.id = id;
        this.name = name;
        this.username = username;
        this.email = email;
        this.api_token = api_token;
        this.loggedin = loggedin;
    }

    public boolean getLoggedin() {
        return loggedin;
    }

    public void setLoggedin(boolean loggedin) {
        this.loggedin = loggedin;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getApi_token() {
        return api_token;
    }

    public void setApi_token(String api_token) {
        this.api_token = api_token;
    }
}
