package com.mfadib.storebird.app.adapters;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.StrictMode;
import android.support.v4.app.FragmentActivity;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.mfadib.storebird.R;
import com.mfadib.storebird.app.Session;
import com.mfadib.storebird.app.models.Post;
import com.mfadib.storebird.app.views.FragmentPost;
import com.mfadib.storebird.app.views.FragmentPostDetail;
import com.mfadib.storebird.app.views.FragmentPostEdit;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.List;

import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

/**
 * Created by WIN 8.1 Pro on 12/21/2016.
 */

public class PostAdapter extends RecyclerView.Adapter<PostAdapter.ViewHolder>{
    private Context context;
    private List<Post> posts;
    private Session session;
    String BASE_URL = "http://storebird.mfadib.com/api/v1/";

    public PostAdapter(Context context, List<Post> posts) {
        super();
        this.context = context;
        this.posts = posts;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v  = LayoutInflater.from(parent.getContext()).inflate(R.layout.data_listview, parent, false);
        ViewHolder viewHolder = new ViewHolder(v);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        Post i = posts.get(position);
        holder.id.setText(String.valueOf(i.getId()));
        holder.title.setText(i.getTitle());
        holder.posttype.setText(i.getPost_type());
        holder.created.setText(i.getUpdated_at());
        if((i.getImage() == null) || (i.getImage() == "")){
            Glide.with(context).load("http://storebird.mfadib.com/images/notfound.jpg")
                    .diskCacheStrategy(DiskCacheStrategy.SOURCE).into(holder.image);
        }else{
            Glide.with(context).load("http://storebird.mfadib.com/images/"+i.getImage())
                    .diskCacheStrategy(DiskCacheStrategy.SOURCE).into(holder.image);
        }

    }

    @Override
    public int getItemCount() {
        return posts.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public TextView id,title,tvEditContent,tvDeleteContent,posttype,created,dash;
        public ImageView image;
        public ViewHolder(View viewHolder) {
            super(viewHolder);
            id = (TextView)viewHolder.findViewById(R.id.tvId);
            title = (TextView)viewHolder.findViewById(R.id.tvTitle);
            image = (ImageView)viewHolder.findViewById(R.id.img_thumbnail);
            created = (TextView)viewHolder.findViewById(R.id.tvEtc);
            dash = (TextView)viewHolder.findViewById(R.id.tvDash);
            dash.setVisibility(View.VISIBLE);
            posttype = (TextView)viewHolder.findViewById(R.id.tvEtc2);
            session = new Session(viewHolder.getContext());
            if ((session.loggedin()) &&(session.getUsertype().equals("admin"))) {
                tvEditContent = (TextView)viewHolder.findViewById(R.id.tvEditContent);
                tvDeleteContent = (TextView)viewHolder.findViewById(R.id.tvDeleteContent);
                tvEditContent.setVisibility(View.VISIBLE);
                tvDeleteContent.setVisibility(View.VISIBLE);

                tvEditContent.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Bundle bundle = new Bundle();
                        bundle.putString("post_id",id.getText().toString());
                        FragmentPostEdit frag = new FragmentPostEdit();
                        frag.setArguments(bundle);
                        try{
                            ((FragmentActivity) context)
                                    .getSupportFragmentManager().beginTransaction()
                                    .replace(R.id.fragment_main, frag).commit();
                        }catch (Exception e){
                            e.printStackTrace();
                        }
                    }
                });

                tvDeleteContent.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        deleteContent(id.getText().toString());
                    }
                });

            }
            image.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Bundle bundle = new Bundle();
                    bundle.putString("post_id",id.getText().toString());
                    FragmentPostDetail frag = new FragmentPostDetail();

                    frag.setArguments(bundle);
                    try{
                        ((FragmentActivity) context)
                                .getSupportFragmentManager().beginTransaction()
                                .replace(R.id.fragment_main, frag).commit();

                    }catch (Exception e){
                        e.printStackTrace();
                    }
                }
            });
        }
    }

    @Override
    public void onAttachedToRecyclerView(RecyclerView recyclerView){
        super.onAttachedToRecyclerView(recyclerView);
    }

    public void deleteContent(final String id){
        AsyncTask<Integer, Void, Integer> task = new AsyncTask<Integer, Void, Integer>() {
            ProgressDialog pd;

            @Override
            protected void onPreExecute() {
                pd = new ProgressDialog(context);
                pd.setTitle("Please wait...");
                pd.setMessage("Deleting data from server");
                pd.setIndeterminate(true);
                pd.setCancelable(true);
                pd.show();
            }

            @Override
            protected Integer doInBackground(Integer... integers) {
                int result = 0;
                StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
                StrictMode.setThreadPolicy(policy);

                FormBody.Builder formBulider = new FormBody.Builder()
                        .add("id", String.valueOf(id));
                RequestBody formBody = formBulider.build();

                OkHttpClient com = new OkHttpClient();
                Request req = new Request.Builder()
                        .url(BASE_URL + "post/"+String.valueOf(id))
                        .delete(formBody)
                        .build();
                try {
                    Response resp = com.newCall(req).execute();
                    JSONObject jsonObject = new JSONObject(resp.body().string());
                    boolean status = jsonObject.getBoolean("status");
                    if(status == true){
                        result = 1;
                    }else{
                        result = 0;
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                return result;
            }

            @Override
            protected void onPostExecute(Integer result) {
                if(result == 1){
                    try{
                        ((FragmentActivity) context)
                                .getSupportFragmentManager().beginTransaction()
                                .replace(R.id.fragment_main, FragmentPost.class.newInstance()).commit();
                    }catch (Exception e){
                        e.printStackTrace();
                    }
                    Toast.makeText(context,"Konten berhasil dihapus",Toast.LENGTH_LONG).show();
                }else{
                    Toast.makeText(context,"Gagal menghapus konten",Toast.LENGTH_LONG).show();
                }
                pd.dismiss();
            }
        };

        task.execute();
    }
}
