package com.mfadib.storebird.app.controllers;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.design.widget.NavigationView;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;

import com.mfadib.storebird.R;
import com.mfadib.storebird.app.Session;
import com.mfadib.storebird.app.views.FragmentForum;
import com.mfadib.storebird.app.views.FragmentLogin;
import com.mfadib.storebird.app.views.FragmentMain;
import com.mfadib.storebird.app.views.FragmentPost;
import com.mfadib.storebird.app.views.FragmentRegister;
import com.mfadib.storebird.app.views.FragmentStore;
import com.mfadib.storebird.app.views.FragmentUser;

public class MainActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {
    private DrawerLayout drawer;
    private NavigationView navigationView;
    private FragmentManager fragmentManager;
    private FragmentTransaction fragmentTransaction;
    private Session session;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.setDrawerListener(toggle);
        toggle.syncState();
        navigationView = (NavigationView)findViewById(R.id.nav_view);
        setupDrawerContent(navigationView);
        session = new Session(getApplicationContext());
        Fragment fragment = null;
        Class fragmentClass = null;
        fragmentClass = FragmentMain.class;
        try {
            fragment = (Fragment) fragmentClass.newInstance();
        } catch (Exception e) {
            e.printStackTrace();
        }
        if(savedInstanceState == null) {
            fragmentManager = getSupportFragmentManager();
            fragmentManager.beginTransaction().replace(R.id.fragment_main, fragment).commit();
        }

    }


    private void setupDrawerContent(NavigationView navigationView) {
        navigationView.setNavigationItemSelectedListener(
                new NavigationView.OnNavigationItemSelectedListener() {
                    @Override
                    public boolean onNavigationItemSelected(MenuItem menuItem) {
                        selectDrawerItem(menuItem);
                        return true;
                    }
                });

    }


    public void selectDrawerItem(MenuItem menuItem) {
        int id = menuItem.getItemId();
        Fragment fragment = null;
        Class fragmentClass;
        if (id == R.id.nav_home) {
            Log.d("Nav Click","Home");
            fragmentClass = FragmentMain.class;
        }else if (id == R.id.nav_post) {
            Log.d("Nav Click","Post");
            fragmentClass = FragmentPost.class;
        } else if (id == R.id.nav_forum) {
            Log.d("Nav Click","Forum");
            fragmentClass = FragmentForum.class;
        } else if (id == R.id.nav_login) {
            Log.d("Nav Click","Login");
            fragmentClass = FragmentLogin.class;
        } else if (id == R.id.nav_register) {
            Log.d("Nav Click","Register");
            fragmentClass = FragmentRegister.class;
        } else if (id == R.id.nav_profile) {
            Log.d("Nav Click","Register");
            fragmentClass = FragmentRegister.class;
        } else if (id == R.id.nav_setting) {
            Log.d("Nav Click","Register");
            fragmentClass = FragmentRegister.class;
        } else if (id == R.id.nav_user) {
            Log.d("Nav Click","User");
            fragmentClass = FragmentUser.class;
        } else if (id == R.id.nav_logout) {
            session.setLoggedin(false,0,null,null);
            fragmentClass = FragmentMain.class;
        }else if(id == R.id.nav_exit){
            Log.d("Nav Click","Exit");
            fragmentClass = null;
            finish();
            System.exit(0);
        }else{
            Log.d("Nav Click","Default");
            fragmentClass = FragmentStore.class;
        }
        try{
            fragment = (Fragment)fragmentClass.newInstance();
        }catch (Exception e){
            e.printStackTrace();
        }

        fragmentManager = getSupportFragmentManager();
        fragmentManager.beginTransaction().replace(R.id.fragment_main, fragment)/*.addToBackStack(null)*/
                .commit();

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);

        // Highlight the selected item has been done by NavigationView
        menuItem.setChecked(true);
        // Set action bar title
        setTitle(menuItem.getTitle());
        // Close the navigation drawer
        drawer.closeDrawer(GravityCompat.START);
        //drawer.closeDrawers();
    }


    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }

        if(fragmentManager.getBackStackEntryCount() > 0){
            fragmentManager.popBackStack();
        }else{
            super.onBackPressed();
        }
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        int id = item.getItemId();
        Fragment fragment = null;
        Class fragmentClass;
        if (id == R.id.nav_home) {
            Log.d("Nav Click","Home");
            fragmentClass = FragmentPost.class;
        }else if (id == R.id.nav_post) {
            Log.d("Nav Click","Post");
            fragmentClass = FragmentPost.class;
        } else if (id == R.id.nav_forum) {
            Log.d("Nav Click","Forum");
            fragmentClass = FragmentForum.class;
        } else if (id == R.id.nav_login) {
            Log.d("Nav Click","Login");
            fragmentClass = FragmentLogin.class;
        } else if (id == R.id.nav_register) {
            Log.d("Nav Click","Register");
            fragmentClass = FragmentRegister.class;
        } else if (id == R.id.nav_profile) {
            Log.d("Nav Click","Register");
            fragmentClass = FragmentRegister.class;
        } else if (id == R.id.nav_user) {
            Log.d("Nav Click","User");
            fragmentClass = FragmentUser.class;
        } else if (id == R.id.nav_setting) {
            Log.d("Nav Click","Register");
            fragmentClass = FragmentRegister.class;
        } else if (id == R.id.nav_logout) {
            session.setLoggedin(false,0,null,null);
            fragmentClass = FragmentMain.class;
        } else if(id == R.id.nav_exit){
            Log.d("Nav Click","Exit");
            fragmentClass = null;
            finish();
            System.exit(0);
        }else{
            Log.d("Nav Click","Default");
            fragmentClass = FragmentStore.class;
        }

        try{
            fragment = (Fragment)fragmentClass.newInstance();
        }catch (Exception e){
            e.printStackTrace();
        }

        fragmentManager = getSupportFragmentManager();
        fragmentManager.beginTransaction().replace(R.id.fragment_main, fragment)
//                .addToBackStack(null)
                .commit();

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.requestLayout();
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

}
