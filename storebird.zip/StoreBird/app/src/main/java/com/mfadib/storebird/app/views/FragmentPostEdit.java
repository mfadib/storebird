package com.mfadib.storebird.app.views;


import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import com.mfadib.storebird.R;
import com.mfadib.storebird.app.Session;
import com.mfadib.storebird.app.adapters.PostEditAdapter;
import com.mfadib.storebird.app.models.Post;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

/**
 * A simple {@link Fragment} subclass.
 */
public class FragmentPostEdit extends Fragment {


    String BASE_URL = "http://storebird.mfadib.com/api/v1/";
    private RecyclerView recyclerView, recyclerComment;
    private GridLayoutManager gridLayoutManager, glm;
    private Session session;
    private String post_id;
    private PostEditAdapter adapter;
    private EditText etTitle,etDescription;
    private Spinner spinPosttype;
    private Button btnEdit;
    private List<Post> dataDetail;

    public FragmentPostEdit() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_main, container, false);
        recyclerView = (RecyclerView)v.findViewById(R.id.recycler_view);
        session = new Session(v.getContext());
        Bundle arguments = this.getArguments();

        if(arguments!=null) {

            post_id = arguments.getString("post_id",null);
        }

        dataDetail = new ArrayList<>();
        load_detail(post_id);
        gridLayoutManager = new GridLayoutManager(getActivity(),1);
        recyclerView.setLayoutManager(gridLayoutManager);
        adapter = new PostEditAdapter(getContext(),dataDetail);
        recyclerView.setAdapter(adapter);

        return v;
    }

    private void load_detail(final String id) {
        AsyncTask<Integer, Void, Void> task = new AsyncTask<Integer, Void, Void>() {
            ProgressDialog pd;
            @Override
            protected void onPreExecute(){
                pd = new ProgressDialog(getContext());
                pd.setTitle("Please wait...");
                pd.setMessage("Get data from server");
                pd.setIndeterminate(true);
                pd.setCancelable(false);
                pd.show();
            }
            @Override
            protected Void doInBackground(Integer... integers) {
                OkHttpClient client = new OkHttpClient();
                Request request = new Request.Builder()
                        .url(BASE_URL+"post/"+id).build();
//                RestForum api = client
                try {
                    Response response = client.newCall(request).execute();
                    JSONObject jsonObject = new JSONObject(response.body().string());
                    JSONArray jsonArray = jsonObject.getJSONArray("data");
                    for(int i = 0; i<jsonArray.length();i++){
                        JSONObject obj = jsonArray.getJSONObject(i);
                        Post posts= new Post(obj.getInt("id"),obj.getString("title"),
                                obj.getString("description"),obj.getString("post_type")
                                ,obj.getInt("status"),obj.getString("image"),
                                obj.getString("created_at"),obj.getString("updated_at"));
                        dataDetail.add(posts);
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                } catch (JSONException e) {
                    e.printStackTrace();
                }

                return null;
            }

            @Override
            protected void onPostExecute(Void aVoid){
                adapter.notifyDataSetChanged();
                pd.dismiss();
            }
        };

        task.execute();
    }
}
