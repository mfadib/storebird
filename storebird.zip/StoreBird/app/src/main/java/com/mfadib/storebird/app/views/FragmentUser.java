package com.mfadib.storebird.app.views;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.mfadib.storebird.R;
import com.mfadib.storebird.app.Session;
import com.mfadib.storebird.app.adapters.UsermenuAdapter;

/**
 * A simple {@link Fragment} subclass.
 */
public class FragmentUser extends Fragment {

    private Session session;
    RecyclerView recyclerView;
    RecyclerView.LayoutManager layoutManager;
    RecyclerView.Adapter adapter;

    public FragmentUser() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view =  inflater.inflate(R.layout.fragment_main, container, false);
        session = new Session(view.getContext());
        if(!session.loggedin()){
            try {
                if(savedInstanceState == null) {
                    ((FragmentActivity) getContext())
                            .getSupportFragmentManager().beginTransaction()
                            .replace(R.id.fragment_main, FragmentLogin.class.newInstance()).commit();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }

        }

        recyclerView = (RecyclerView)view.findViewById(R.id.recycler_view);
//        recyclerView.setHasFixedSize(true);

        layoutManager = new GridLayoutManager(getActivity(),4);
        recyclerView.setLayoutManager(layoutManager);

        adapter = new UsermenuAdapter(view.getContext());
        recyclerView.setAdapter(adapter);
        return view;
    }

    public void onBackPressed(){
        ((FragmentActivity)getContext()).getSupportFragmentManager().popBackStack();
    }

}
