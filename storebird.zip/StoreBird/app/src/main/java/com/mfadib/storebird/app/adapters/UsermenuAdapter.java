package com.mfadib.storebird.app.adapters;

import android.app.Activity;
import android.content.Context;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.mfadib.storebird.R;
import com.mfadib.storebird.app.Session;
import com.mfadib.storebird.app.menus.Mainmenu;
import com.mfadib.storebird.app.views.FragmentForum;
import com.mfadib.storebird.app.views.FragmentMain;
import com.mfadib.storebird.app.views.FragmentProfile;
import com.mfadib.storebird.app.views.FragmentSetting;
import com.mfadib.storebird.app.views.FragmentUser;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by WIN 8.1 Pro on 12/30/2016.
 */

public class UsermenuAdapter extends RecyclerView.Adapter<UsermenuAdapter.ViewHolder> {
    List<Mainmenu> menumenus;
    Context ctx;
    Activity activity;
    private Session session;
//    public UsermenuAdapter(Context ctx, Activity activity) {
//        this.ctx = ctx;
//        this.activity = activity;
//    }

    public UsermenuAdapter(Context ctx){
        this.ctx = ctx;
//        super();
        session = new Session(ctx);
        menumenus = new ArrayList<Mainmenu>();
        Mainmenu specials = new Mainmenu();
        specials.setName("Home");
        specials.setImgThumbnail(R.drawable.ic_home);
        menumenus.add(specials);

        specials = new Mainmenu();
        specials.setName("Profile");
        specials.setImgThumbnail(R.drawable.ic_user);
        menumenus.add(specials);

        specials = new Mainmenu();
        specials.setName("Forum");
        specials.setImgThumbnail(R.drawable.ic_forums);
        menumenus.add(specials);

        specials = new Mainmenu();
        specials.setName("Logout");
        specials.setImgThumbnail(R.drawable.ic_logout);
        menumenus.add(specials);

    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v  = LayoutInflater.from(parent.getContext()).inflate(R.layout.gridmenu, parent, false);
        ViewHolder viewHolder = new ViewHolder(v);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        final Mainmenu menu = menumenus.get(position);
        holder.textSpecial.setText(menu.getName());
        holder.imgThumbnail.setImageResource(menu.getImgThumbnail());
    }

    @Override
    public int getItemCount() {
        return menumenus.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder{
        public ImageView imgThumbnail;
        public TextView textSpecial;
        public ViewHolder(final View viewHolder){
            super(viewHolder);
            imgThumbnail = (ImageView)viewHolder.findViewById(R.id.img_thumbnail);
            textSpecial = (TextView)viewHolder.findViewById(R.id.tv_special);

            imgThumbnail.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    String item = textSpecial.getText().toString();
                    Fragment fragment = null;
                    Class fragmentClass;
                    switch(item){
                        case "Home":
                            fragmentClass = FragmentMain.class;
                            break;
                        case "Profile":
                            fragmentClass = FragmentProfile.class;
                            break;
                        case "Forum":
                            fragmentClass = FragmentForum.class;
                            break;
                        case "Logout":
                            fragmentClass = FragmentMain.class;
                            session.setLoggedin(false,0,null, null);
                            break;
                        default:
                            fragmentClass = FragmentUser.class;
                            break;
                    }

                    try{
                        fragment = (Fragment)fragmentClass.newInstance();
                    }catch (Exception e){
                        e.printStackTrace();
                    }

                    ((FragmentActivity)viewHolder.getContext()).getSupportFragmentManager().beginTransaction().replace(R.id.fragment_main, fragment).commit();
                }
            });
        }


    }
}
