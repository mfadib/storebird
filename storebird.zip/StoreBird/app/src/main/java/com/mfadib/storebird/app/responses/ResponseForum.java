package com.mfadib.storebird.app.responses;

/**
 * Created by WIN 8.1 Pro on 12/20/2016.
 */
import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.mfadib.storebird.app.models.Forum;

public class ResponseForum {


        @SerializedName("status")
        @Expose
        private Boolean status;
        @SerializedName("data")
        @Expose
        private List<Forum> data = null;
        @SerializedName("message")
        @Expose
        private String message;

        public Boolean getStatus() {
            return status;
        }

        public void setStatus(Boolean status) {
            this.status = status;
        }

        public List<Forum> getData() {
            return data;
        }

        public void setData(List<Forum> data) {
            this.data = data;
        }

        public String getMessage() {
            return message;
        }

        public void setMessage(String message) {
            this.message = message;
        }


}
