package com.mfadib.storebird.app.views;


import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.mfadib.storebird.R;
import com.mfadib.storebird.app.Session;
import com.mfadib.storebird.app.adapters.PostAdapter;
import com.mfadib.storebird.app.models.Post;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

/**
 * A simple {@link Fragment} subclass.
 */
public class FragmentPost extends Fragment {

    String BASE_URL = "http://storebird.mfadib.com/api/v1/";
    private RecyclerView recyclerView;
    private GridLayoutManager gridLayoutManager;
    private PostAdapter adapter;
    private List<Post> dataList;
    private FloatingActionButton fab;
    private Session session;


    public FragmentPost() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the profile_user for this fragment
        View view = inflater.inflate(R.layout.fragment_main, container, false);

        recyclerView = (RecyclerView)view.findViewById(R.id.recycler_view);
        session = new Session(view.getContext());
//        recyclerView.setHasFixedSize(true);
        dataList = new ArrayList<>();
        load_data_from_server();
        gridLayoutManager = new GridLayoutManager(getActivity(),1);
        recyclerView.setLayoutManager(gridLayoutManager);

        adapter = new PostAdapter(getContext(),dataList);
        recyclerView.setAdapter(adapter);

        if(session.loggedin() && session.getUsertype().equals("admin")){
            fab = (FloatingActionButton)view.findViewById(R.id.fabAdd);
            fab.setVisibility(View.VISIBLE);
            fab.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    try {
                        ((FragmentActivity) getContext())
                                .getSupportFragmentManager().beginTransaction()
                                .replace(R.id.fragment_main, FragmentAddPost.class.newInstance()).commit();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            });
        }

        return view;
    }

    private void load_data_from_server() {

        AsyncTask<Integer, Void, Void> task = new AsyncTask<Integer, Void, Void>() {
            ProgressDialog pd;
            @Override
            protected void onPreExecute(){
                pd = new ProgressDialog(getContext());
                pd.setTitle("Please wait...");
                pd.setMessage("Get data from server");
                pd.setIndeterminate(true);
                pd.setCancelable(false);
                pd.show();
            }
            @Override
            protected Void doInBackground(Integer... integers) {
                OkHttpClient client = new OkHttpClient();
                Request request = new Request.Builder()
                        .url(BASE_URL+"posts").build();
                Log.d("Request on ",BASE_URL+"posts");
                try {
                    Response response = client.newCall(request).execute();
                    JSONObject jsonObject = new JSONObject(response.body().string());
                    JSONArray jsonArray = jsonObject.getJSONArray("data");
                    String msg = jsonObject.getString("message");
                    boolean status = jsonObject.getBoolean("status");
                    Log.d("Response","Status="+status+", and message="+msg);
                    Log.d("Your data", jsonArray.toString());
                    for(int i = 0; i<jsonArray.length();i++){
                        JSONObject obj = jsonArray.getJSONObject(i);
                        Post posts = new Post(obj.getInt("id"),obj.getString("title"),
                                obj.getString("description"),obj.getString("post_type"),
                                obj.getInt("status"),obj.getString("image"),
                                obj.getString("created_at"),obj.getString("updated_at"));
                        dataList.add(posts);
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                } catch (JSONException e) {
                    e.printStackTrace();
                }

                return null;
            }

            @Override
            protected void onPostExecute(Void aVoid){
                adapter.notifyDataSetChanged();
                pd.dismiss();
            }
        };

        task.execute();
    }

}
