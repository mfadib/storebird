package com.mfadib.storebird.app.views;


import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.StrictMode;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v7.widget.CardView;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.mfadib.storebird.R;
import com.mfadib.storebird.app.Session;
import com.mfadib.storebird.app.adapters.BirdEditAdapter;
import com.mfadib.storebird.app.adapters.CommentAdapter;
import com.mfadib.storebird.app.adapters.DetailBirdAdapter;
import com.mfadib.storebird.app.models.Bird;
import com.mfadib.storebird.app.models.Comment;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

/**
 * A simple {@link Fragment} subclass.
 */
public class FragmentStoreDetail extends Fragment {



    String BASE_URL = "http://storebird.mfadib.com/api/v1/";
    private RecyclerView recyclerView, recyclerComment;
    private GridLayoutManager gridLayoutManager, glm;
    private Session session;
    private DetailBirdAdapter adapterDetail;
    private CommentAdapter adapterComment;
    private List<Bird> dataDetail;
    private List<Comment> dataComment;
    private String bird_id = null;
    private CardView formComment,loginAccess;
    private TextView tvMessage,tvLogin, tvRegister;
    private EditText etComment;
    private Button btnAddComment;

    public FragmentStoreDetail() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             final Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_detail, container, false);
        session = new Session(view.getContext());
        formComment = (CardView)view.findViewById(R.id.layout_form_comment);
        loginAccess = (CardView)view.findViewById(R.id.layout_login_access);

        recyclerView = (RecyclerView)view.findViewById(R.id.recycler_detail);
        recyclerComment = (RecyclerView)view.findViewById(R.id.recycler_comments);
        Bundle arguments = this.getArguments();

        if(arguments!=null) {

            bird_id = arguments.getString("bird_id",null);
        }

//        forum_id = getArguments().toString();
        dataDetail = new ArrayList<>();
        load_detail(bird_id);
        gridLayoutManager = new GridLayoutManager(getActivity(),1);
        recyclerView.setLayoutManager(gridLayoutManager);
        adapterDetail = new DetailBirdAdapter(getContext(),dataDetail);
        recyclerView.setAdapter(adapterDetail);

        dataComment = new ArrayList<>();
        glm = new GridLayoutManager(getActivity(),1);
        recyclerComment.setLayoutManager(glm);
        adapterComment = new CommentAdapter(getContext(),dataComment);
        recyclerComment.setAdapter(adapterComment);

        if(!session.loggedin()){
            tvLogin = (TextView)view.findViewById(R.id.tvLogin);
            tvRegister = (TextView)view.findViewById(R.id.tvRegister);
            tvLogin.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    try{
                        if(savedInstanceState == null) {
                            ((FragmentActivity) getContext())
                                    .getSupportFragmentManager().beginTransaction()
                                    .replace(R.id.fragment_main, FragmentLogin.class.newInstance()).commit();
                        }

                    }catch (Exception e){
                        e.printStackTrace();
                    }
                }
            });

            tvRegister.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    try{
                        if(savedInstanceState == null) {
                            ((FragmentActivity) getContext())
                                    .getSupportFragmentManager().beginTransaction()
                                    .replace(R.id.fragment_main, FragmentRegister.class.newInstance()).commit();
                        }

                    }catch (Exception e){
                        e.printStackTrace();
                    }
                }
            });
        }

        if(session.loggedin()){
            etComment = (EditText)view.findViewById(R.id.etComment);
            btnAddComment = (Button)view.findViewById(R.id.btnAddComment);
            btnAddComment.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    String[] data = {bird_id,String.valueOf(session.getId()),etComment.getText().toString(),"1"};
                    insertComment(data);
                }
            });
        }
        return view;
    }

    private void insertComment(final String[] data){

        AsyncTask<Integer, Integer, Integer> task = new AsyncTask<Integer, Integer, Integer>() {
            ProgressDialog pd;

            @Override
            protected void onPreExecute() {
                pd = new ProgressDialog(getContext());
                pd.setTitle("Please wait...");
                pd.setMessage("Insert data to server");
                pd.setIndeterminate(true);
                pd.setCancelable(false);
                pd.show();
            }

            @Override
            protected Integer doInBackground(Integer... integers) {

                int result = 0;

                try{
                    StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
                    StrictMode.setThreadPolicy(policy);

                    FormBody.Builder formBulider = new FormBody.Builder()
                            .add("relation_id", String.valueOf(data[0]))
                            .add("comment_type", "bird")
                            .add("user_id", String.valueOf(data[1]))
                            .add("comment", String.valueOf(data[2]))
                            .add("status", String.valueOf(data[3]));
                    RequestBody formBody = formBulider.build();

                    OkHttpClient com = new OkHttpClient();
                    Request req = new Request.Builder()
                            .url(BASE_URL + "comment")
                            .post(formBody)
                            .build();
                    try {
                        Response resp = com.newCall(req).execute();
                        JSONObject jsonObject = new JSONObject(resp.body().string());
                        boolean status = jsonObject.getBoolean("status");
                        String msg = jsonObject.getString("message");
                        Log.d("Response From server",String.valueOf(status));
                        Log.d("Response From server",String.valueOf(msg));
                        if(status == true){
                            result = 1;
                        }else{
                            result= 0;
                        }
                    } catch (IOException e) {
                        e.printStackTrace();
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                } catch (Exception e) {
                    result = 0;
                }

                return result;
            }

            @Override
            protected void onPostExecute(Integer res) {
                if(res == 1){
                    Toast.makeText(getContext(),"Komentar berhasil ditambah",Toast.LENGTH_LONG).show();
                    Bundle bundle = new Bundle();
                    bundle.putString("bird_id",bird_id);
                    FragmentStoreDetail frag = new FragmentStoreDetail();
                    frag.setArguments(bundle);
                    try{
                        ((FragmentActivity) getContext())
                                .getSupportFragmentManager().beginTransaction()
                                .replace(R.id.fragment_main, frag).commit();
                    }catch (Exception e){
                        e.printStackTrace();
                    }
                }else{
                    Toast.makeText(getContext(),"Gagal saat memasukan data",Toast.LENGTH_LONG).show();
                }
                pd.dismiss();
            }
        };

        task.execute();
    }

    private void load_detail(final String id) {
        AsyncTask<Integer, Void, Void> task = new AsyncTask<Integer, Void, Void>() {
            ProgressDialog pd;
            @Override
            protected void onPreExecute(){
                pd = new ProgressDialog(getContext());
                pd.setTitle("Please wait...");
                pd.setMessage("Get data from server");
                pd.setIndeterminate(true);
                pd.setCancelable(false);
                pd.show();
            }
            @Override
            protected Void doInBackground(Integer... integers) {
                OkHttpClient client = new OkHttpClient();
                Request request = new Request.Builder()
                        .url(BASE_URL+"bird/"+id).build();
//                RestForum api = client
                try {
                    Response response = client.newCall(request).execute();
                    JSONObject jsonObject = new JSONObject(response.body().string());
                    JSONArray jsonArray = jsonObject.getJSONArray("data");
                    for(int i = 0; i<jsonArray.length();i++){
                        JSONObject obj = jsonArray.getJSONObject(i);
                        Bird birds = new Bird(obj.getInt("id"),obj.getString("title"),
                                obj.getString("description"),obj.getString("info"),obj.getString("price"),
                                obj.getInt("status"),obj.getString("photo"),
                                obj.getString("created_at"),obj.getString("updated_at"));
                        dataDetail.add(birds);
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                } catch (JSONException e) {
                    e.printStackTrace();
                }

                OkHttpClient com = new OkHttpClient();
                Request req = new Request.Builder()
                        .url(BASE_URL+"comments/view/"+bird_id+"/bird").build();
//                RestForum api = client
                try {
                    Response resp = com.newCall(req).execute();
                    JSONObject jsonObject = new JSONObject(resp.body().string());
                    JSONArray jsonArray = jsonObject.getJSONArray("data");
                    for(int i = 0; i<jsonArray.length();i++){
                        JSONObject obj = jsonArray.getJSONObject(i);
                        String user = get_username(obj.getString("user_id"));
                        Comment comments = new Comment(obj.getInt("id"),obj.getInt("user_id"),obj.getInt("relation_id"),user,
                                obj.getString("comment_type"),obj.getInt("comment_parent"),
                                obj.getString("comment"),obj.getString("status"),
                                obj.getString("created_at"),obj.getString("updated_at"));
                        dataComment.add(comments);
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                } catch (JSONException e) {
                    e.printStackTrace();
                }

                return null;
            }

            @Override
            protected void onPostExecute(Void aVoid){
                adapterDetail.notifyDataSetChanged();
                adapterComment.notifyDataSetChanged();
                if(session.loggedin()){
                    formComment.setVisibility(View.VISIBLE);
                }else{
                    loginAccess.setVisibility(View.VISIBLE);
                    tvMessage = (TextView)getView().findViewById(R.id.tvMessage);
                    tvMessage.setText("Login untuk komentar forum ini");
                }
                pd.dismiss();
            }
        };
        task.execute();
    }

    private String get_username(String name){
        String result = "";
        OkHttpClient com = new OkHttpClient();
        Request req = new Request.Builder()
                .url(BASE_URL+"user/"+name).build();
        try {
            Response resp = com.newCall(req).execute();
            JSONObject jsonObject = new JSONObject(resp.body().string());
            JSONArray jsonArray = jsonObject.getJSONArray("data");
            for(int i = 0; i<jsonArray.length();i++){
                JSONObject obj = jsonArray.getJSONObject(i);
                result = obj.getString("username");
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return result;
    }

}
