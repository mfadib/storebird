package com.mfadib.storebird.app.adapters;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.mfadib.storebird.R;
import com.mfadib.storebird.app.models.Post;

import java.util.List;

/**
 * Created by WIN 8.1 Pro on 1/3/2017.
 */

public class DetailPostAdapter extends RecyclerView.Adapter<DetailPostAdapter.ViewHolder>  {

    private Context context;
    private List<Post> posts;

    public DetailPostAdapter(Context context, List<Post> posts) {
        super();
        this.context = context;
        this.posts = posts;
    }

    @Override
    public DetailPostAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v  = LayoutInflater.from(parent.getContext()).inflate(R.layout.data_listview, parent, false);
        DetailPostAdapter.ViewHolder viewHolder = new DetailPostAdapter.ViewHolder(v);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(DetailPostAdapter.ViewHolder holder, int position) {
        Post i = posts.get(position);
        holder.id.setText(String.valueOf(i.getId()));
        holder.title.setText(i.getTitle());
        holder.description.setText(i.getDescription());
        holder.post_type.setText(i.getPost_type());
        holder.created.setText(i.getUpdated_at());
        if((i.getImage() == null) || (i.getImage() == "")){
            Glide.with(context).load("http://storebird.mfadib.com/images/notfound.jpg")
                    .diskCacheStrategy(DiskCacheStrategy.SOURCE).into(holder.image);
        }else{
            Glide.with(context).load("http://storebird.mfadib.com/images/"+i.getImage())
                    .diskCacheStrategy(DiskCacheStrategy.SOURCE).into(holder.image);
        }
    }

    @Override
    public int getItemCount() {
        return posts.size();
    }


    public class ViewHolder extends RecyclerView.ViewHolder{
        public TextView id,title,description,created,post_type,dash;
        public ImageView image;
        public ViewHolder(final View viewHolder){
            super(viewHolder);
            id = (TextView)viewHolder.findViewById(R.id.tvId);
            title = (TextView)viewHolder.findViewById(R.id.tvTitle);
            description = (TextView)viewHolder.findViewById(R.id.tvDescription);
            image = (ImageView)viewHolder.findViewById(R.id.img_thumbnail);
            created = (TextView)viewHolder.findViewById(R.id.tvEtc);
            post_type = (TextView)viewHolder.findViewById(R.id.tvEtc2);
            dash = (TextView)viewHolder.findViewById(R.id.tvDash);
            dash.setVisibility(View.VISIBLE);
        }
    }

    @Override
    public void onAttachedToRecyclerView(RecyclerView recyclerView){
        super.onAttachedToRecyclerView(recyclerView);
    }
}
