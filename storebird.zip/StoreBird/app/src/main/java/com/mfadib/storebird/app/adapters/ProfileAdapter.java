package com.mfadib.storebird.app.adapters;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.AsyncTask;
import android.os.StrictMode;
import android.support.v4.app.FragmentActivity;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.mfadib.storebird.R;
import com.mfadib.storebird.app.Session;
import com.mfadib.storebird.app.models.User;
import com.mfadib.storebird.app.views.FragmentLogin;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.List;

import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

import static java.security.AccessController.getContext;

/**
 * Created by WIN 8.1 Pro on 12/30/2016.
 */

public class ProfileAdapter extends RecyclerView.Adapter<ProfileAdapter.ViewHolder>{
    private Context context;
    private List<User> users;
    String BASE_URL = "http://storebird.mfadib.com/api/v1/";
    private Session session;

    public ProfileAdapter(Context context, List<User> users) {
        super();
        this.context = context;
        this.users = users;
    }

    @Override
    public ProfileAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v  = LayoutInflater.from(parent.getContext()).inflate(R.layout.profile_user, parent, false);
        ProfileAdapter.ViewHolder viewHolder = new ProfileAdapter.ViewHolder(v);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(ProfileAdapter.ViewHolder holder, int position) {
        User i = users.get(position);
        holder.name.setText(i.getName());
        holder.username.setText(i.getUsername());
        holder.email.setText(i.getEmail());
        holder.id = i.getId();
    }

    @Override
    public int getItemCount() {
        return users.size();
    }


    public class ViewHolder extends RecyclerView.ViewHolder{
        public EditText name, username, email,oldpassword, newpassword, confirm;
        public int id;
        public Button btnSave;
        public ViewHolder(final View viewHolder){
            super(viewHolder);
            session = new Session(viewHolder.getContext());
            name = (EditText)viewHolder.findViewById(R.id.etName);
            username = (EditText)viewHolder.findViewById(R.id.etUsername);
            email = (EditText)viewHolder.findViewById(R.id.etEmail);
            oldpassword = (EditText)viewHolder.findViewById(R.id.etOldPassword);
            newpassword = (EditText)viewHolder.findViewById(R.id.etNewPassword);
            confirm = (EditText)viewHolder.findViewById(R.id.etConfirm);
            btnSave = (Button)viewHolder.findViewById(R.id.btnSave);
            btnSave.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if((oldpassword.getText().toString().trim().length() != 0) &&
                        (newpassword.getText().toString().trim().length() != 0) &&
                        (confirm.getText().toString().trim().length() != 0)){
                        if(newpassword.getText().toString().equals(confirm.getText().toString())){
                            change_password(view.getContext(),id, email.getText().toString(),oldpassword.getText().toString(),newpassword.getText().toString(), confirm.getText().toString());
                        }else{
                            Toast.makeText(view.getContext(),"Password baru dan konfirmasi tidak sama",Toast.LENGTH_LONG).show();
                        }
                    }else{
                        Toast.makeText(view.getContext(),"Field password tidak boleh kosong",Toast.LENGTH_LONG).show();
                    }
                }

            });
        }
    }

    private void change_password(final Context context,final int id, final String email, final String oldpassword, final String newpassword, final String confirm) {
        AsyncTask<Integer, Void, Integer> task = new AsyncTask<Integer, Void, Integer>() {
            ProgressDialog pd;

            @Override
            protected void onPreExecute() {
                pd = new ProgressDialog(context);
                pd.setTitle("Please wait...");
                pd.setMessage("Check your password");
                pd.setIndeterminate(true);
                pd.setCancelable(true);
                pd.show();
            }

            @Override
            protected Integer doInBackground(Integer... integers) {

                boolean check = check_old_password(email,oldpassword);
                int result = 0;
                if(check == true){

                    StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
                    StrictMode.setThreadPolicy(policy);

                    FormBody.Builder formBulider = new FormBody.Builder()
                        .add("password", String.valueOf(newpassword));
                    RequestBody formBody = formBulider.build();

                    OkHttpClient com = new OkHttpClient();
                    Request req = new Request.Builder()
                        .url(BASE_URL + "user/"+String.valueOf(id))
                        .put(formBody)
                        .build();
                    try {
                        Response resp = com.newCall(req).execute();
                        JSONObject jsonObject = new JSONObject(resp.body().string());
                        boolean status = jsonObject.getBoolean("status");
                        if(status == true){
                            result = 1;
                        }else{
                            result = 0;
                        }
                    } catch (IOException e) {
                        e.printStackTrace();
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }else{
                    result = 0;
                }
                return result;
            }

            @Override
            protected void onPostExecute(Integer result) {
                if(result == 1){
                    try{
                        ((FragmentActivity) context)
                            .getSupportFragmentManager().beginTransaction()
                            .replace(R.id.fragment_main, FragmentLogin.class.newInstance()).commit();
                    }catch (Exception e){
                        e.printStackTrace();
                    }
                    session.setLoggedin(false,0,null,null);
                    Toast.makeText(context,"Password berhasil diubah",Toast.LENGTH_LONG).show();
                }else{
                    Toast.makeText(context,"Password lama Anda salah",Toast.LENGTH_LONG).show();
                }
                pd.dismiss();
            }
        };

        task.execute();
    }

    private boolean check_old_password(final String email, final String oldpassword) {
        FormBody.Builder formBulider = new FormBody.Builder()
                .add("email", String.valueOf(email))
                .add("password", String.valueOf(oldpassword));
        RequestBody formBody = formBulider.build();

        OkHttpClient com = new OkHttpClient();
        Request req = new Request.Builder()
                .url(BASE_URL + "auth/login")
                .post(formBody)
                .build();
        try {
            Response resp = com.newCall(req).execute();
            JSONObject jsonObject = new JSONObject(resp.body().string());
            boolean status = jsonObject.getBoolean("status");
            if(status == true){
                JSONArray jsonArray = jsonObject.getJSONArray("data");
                if(jsonArray.length() == 1){
                    return true;
                }else{
                    return false;
                }
            }else{
                return false;
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return false;
    }
    @Override
    public void onAttachedToRecyclerView(RecyclerView recyclerView){
        super.onAttachedToRecyclerView(recyclerView);
    }

}
