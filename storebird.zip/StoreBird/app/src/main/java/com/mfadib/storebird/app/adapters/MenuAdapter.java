package com.mfadib.storebird.app.adapters;

import android.app.Activity;
import android.content.Context;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.mfadib.storebird.R;
import com.mfadib.storebird.app.Session;
import com.mfadib.storebird.app.menus.Mainmenu;
import com.mfadib.storebird.app.views.FragmentForum;
import com.mfadib.storebird.app.views.FragmentMain;
import com.mfadib.storebird.app.views.FragmentPost;
import com.mfadib.storebird.app.views.FragmentStore;
import com.mfadib.storebird.app.views.FragmentUser;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by WIN 8.1 Pro on 12/18/2016.
 */

public class MenuAdapter extends RecyclerView.Adapter<MenuAdapter.ViewHolder> {
    List<Mainmenu> menumenus;
    Context ctx;
    Activity activity;
    private Session session;
    public MenuAdapter(Context ctx, Activity activity) {
        this.ctx = ctx;
        this.activity = activity;
    }

    public MenuAdapter(){
        super();
//        session = new Session();
        menumenus = new ArrayList<Mainmenu>();
        Mainmenu specials = new Mainmenu();
        specials.setName("Home");
        specials.setImgThumbnail(R.drawable.ic_home);
        menumenus.add(specials);

        specials = new Mainmenu();
        specials.setName("Forum");
        specials.setImgThumbnail(R.drawable.ic_forums);
        menumenus.add(specials);

        specials = new Mainmenu();
        specials.setName("Store");
        specials.setImgThumbnail(R.drawable.ic_store);
        menumenus.add(specials);

        specials = new Mainmenu();
        specials.setName("Post");
        specials.setImgThumbnail(R.drawable.ic_post);
        menumenus.add(specials);

        specials = new Mainmenu();
        specials.setName("User");
        specials.setImgThumbnail(R.drawable.ic_user);
        menumenus.add(specials);

        specials = new Mainmenu();
        specials.setName("Exit");
        specials.setImgThumbnail(R.drawable.ic_exit);
        menumenus.add(specials);
//
//        if(session.loggedin()){
//            specials = new Mainmenu();
//            specials.setName("Logout");
//            specials.setImgThumbnail(R.drawable.ic_logout);
//            menumenus.add(specials);
//        }

    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v  = LayoutInflater.from(parent.getContext()).inflate(R.layout.gridmenu, parent, false);
        ViewHolder viewHolder = new ViewHolder(v);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        final Mainmenu menu = menumenus.get(position);
        final Context ctx = this.ctx;
        holder.textSpecial.setText(menu.getName());
        holder.imgThumbnail.setImageResource(menu.getImgThumbnail());
    }

    @Override
    public int getItemCount() {
        return menumenus.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder{
        public ImageView imgThumbnail;
        public TextView textSpecial;
        public ViewHolder(final View viewHolder){
            super(viewHolder);
            imgThumbnail = (ImageView)viewHolder.findViewById(R.id.img_thumbnail);
            textSpecial = (TextView)viewHolder.findViewById(R.id.tv_special);

            imgThumbnail.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    String item = textSpecial.getText().toString();
                    Fragment fragment = null;
                    Class fragmentClass;
                    switch(item){
                        case "Home":
                            fragmentClass = FragmentMain.class;
                            break;
                        case "Forum":
                            fragmentClass = FragmentForum.class;
                            break;
                        case "Store":
                            fragmentClass = FragmentStore.class;
                            break;
                        case "Post":
                            fragmentClass = FragmentPost.class;
                            break;
                        case "User":
                            fragmentClass = FragmentUser.class;
                            break;
//                        case "Logout":
//                            session.setLoggedin(false,null,null);
//                            fragmentClass = null;
//                            break;
                        case "Exit":
                            fragmentClass = null;
                            ((Activity)viewHolder.getContext()).finish();
                            System.exit(0);
                            break;
                        default:
                            fragmentClass = FragmentMain.class;
                            break;
                    }

                    try{
                        fragment = (Fragment)fragmentClass.newInstance();
                    }catch (Exception e){
                        e.printStackTrace();
                    }

                    ((FragmentActivity)viewHolder.getContext()).getSupportFragmentManager().beginTransaction().replace(R.id.fragment_main, fragment).commit();
                }
            });
        }


    }
}
