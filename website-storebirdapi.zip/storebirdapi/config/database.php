<?php 

return 
	['default'=>'mysql',
	'fetch' => PDO::FETCH_CLASS,
	'connections' => 
		['mysql' =>
			['driver'	=>'mysql',

			'host'		=>'localhost',
			'database'	=>'dbstore_bird',
			'username'	=>'root',
			'password'	=>'',
			'charset'	=>'utf8',
			'collation' =>'utf8_unicode_ci',
			'prefix'	=>'',
			'strict'	=>false
			]
		]
	];