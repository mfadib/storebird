<?php 


namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Comment;
use App\Libs\Format;
use Validator;


class CommentController extends Controller
{
    private $format;

    public function __construct(Format $format)
    {
        $this->format = $format;
    }


    public function comment($id)
    {
        $comment = Comment::whereId($id);
        if($comment->count() == 1){
            return $this->format->json(true,$comment->get(),'');
        }else{
            return $this->format->json(false,null,'Data tidak ditemukan');
        }
    }

    public function relation_comments($relation_id,$comment_type)
    {
        $comment = Comment::where(['relation_id'=>$relation_id,'comment_type'=>$comment_type]);
        if($comment->count() != 0){
            return $this->format->json(true,$comment->get(),'');
        }else{
            return $this->format->json(false,null,'Data tidak ditemukan');
        }
    }

    public function insert_comment(Request $request)
    {
        $rules = [
            'user_id'=>'required|exists:users,id',
            'relation_id'=>'required',
            'comment_type'=>'required', //forum,post,bird
            // 'comment_parent'=>'required',
            'comment'=>'required',
            'status'=>'required'
        ];
        $validate = Validator::make($request->all(),$rules);
        if($validate->fails()){
            return $this->format->json(false,null,$validate->errors());
        }else{
            $id = Comment::insertGetId($request->all());
            $comments = $this->format->get_data('comments',['id'=>$id])->get();
            return $this->format->json(true,$comments,'Data berhasil ditambah');         
        }
    }

    public function update_comments(Request $request,$id)
    {
        $comment = Comment::whereId($id);
        if($comment->count() == 1){
            $comment->update($request->all());
            $comment = Comment::find($id);
            return $this->format->json(true,$comment,'Data berhasil diubah');
        }else{
            return $this->format->json(false,null,'Data tidak ditemukan');
        }
    }

    public function delete_comments($id)
    {
        $comment = Comment::whereId($id);
        if($comment->count() == 1){
            $comment->delete();
            return $this->format->json(true,[],'Data berhasil dihapus');
        }else{
            return $this->format->json(false,null,'Data tidak ditemukan');
        }
    }


}