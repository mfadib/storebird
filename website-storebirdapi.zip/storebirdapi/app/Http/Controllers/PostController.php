<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Post;
use App\Libs\Format;
use Validator;

class PostController extends Controller
{
    private $format;

    public function __construct(Format $format)
    {
        $this->format = $format;
    }
    
    public function view(){
        return $this->format->json(true,Post::orderBy('updated_at','desc')->get(),'');
    }

    public function detail($id){
        $post = Post::whereId($id);
        if($post->count() == 1){
            return $this->format->json(true,$post->get(),'');
        }else{
            return $this->format->json(false,null,'Data tidak ditemukan');
        }
    }

    public function insert(Request $request){
        // return $request->input('image');
        $rules = [
            'title'=>'required',
            'description'=>'required',
            'post_type'=>'required',
            'status'=>'required'
        ];
        $validate = Validator::make($request->all(),$rules);
        if($validate->fails()){
            return $this->format->json(false,null,$validate->errors());
        }else{
            if($request->hasFile('image')){
                $image = $request->file('image');
                $name_file = 'post-'.time().'-'.str_slug($request->input('title')).'.'.$image->getClientOriginalExtension();
                $img = $image->move('images/',$name_file);
                // return response($img);
                if($img){
                    $insert = [
                        'title'=>$request->input('title'),
                        'description'=>$request->input('description'),
                        'post_type'=>$request->input('post_type'),
                        'status'=>$request->input('status'),
                        'image'=>$name_file,
                    ];

                    $id = Post::insertGetId($insert);
                    $post = $this->format->get_data('posts',['id'=>$id])->get();
                    return $this->format->json(true,$post,'Data berhasil ditambah');
                }else{
                    return $this->format->json(false,null,'Gambar gagal diupload');
                }
            }else{
                return $this->format->json(false,null,'Gambar tidak boleh kosong');
            }
        }
    }

    public function update(Request $request, $id){

        $post = Post::whereId($id);
        if($post->count() == 1){
            $post->update($request->all());
            $post = Post::find($id);
            return $this->format->json(true,$post,'Data berhasil diubah');
        }else{
            return $this->format->json(false,null,'Data tidak ditemukan');
        }
    }

    public function delete($id){
        $post = Post::whereId($id);
        if($post->count() == 1){
            foreach($post->get() as $item);
                unlink('images/'.$item->image);
            $post->delete();
            return $this->format->json(true,[],'Data berhasil dihapus');
        }else{
            return $this->format->json(false,null,'Data tidak ditemukan');
        }
    }

}
