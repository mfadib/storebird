<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Forum;
use App\Comment;
use App\Libs\Format;
use Validator;

class ForumController extends Controller
{
    private $format;

    public function __construct(Format $format)
    {
        $this->format = $format;
    }
    
    public function view(){
        return $this->format->json(true,Forum::orderBy('updated_at','desc')->get(),'');
    }

    public function detail($id){
        $forum = Forum::whereId($id);
        if($forum->count() == 1){
            return $this->format->json(true,$forum->get(),'');
        }else{
            return $this->format->json(false,null,'Data tidak ditemukan');
        }
    }

    public function insert(Request $request){
        $rules = [
            'user_id'=>'required|exists:users,id',
            'title'=>'required',
            'description'=>'required'
        ];
        $validate = Validator::make($request->all(),$rules);
        if($validate->fails()){
            return $this->format->json(false,null,$validate->errors());
        }else{
            $insert = $request->all();
            if($request->hasFile('image')){
                $image = $request->file('image');
                $name_file = 'forum-'.str_random(20).'-'.str_slug($request->input('title')).'.'.$image->getClientOriginalExtension();
                $img = $image->move('images/',$name_file);
                if($img){
                    $insert = [
                        'user_id'=>$request->input('user_id'),
                        'title'=>$request->input('title'),
                        'description'=>$request->input('description'),
                        'image'=>$name_file,
                    ];
                }else{
                    return $this->format->json(false,null,'Gambar gagal diupload');
                }
            }

            $id = Forum::insertGetId($insert);
            $forum = $this->format->get_data('forums',['id'=>$id])->get();
            return $this->format->json(true,$forum,'Data berhasil ditambah');
        }
    }

    public function update(Request $request, $id){

        $forum = Forum::whereId($id);
        if($forum->count() == 1){
            $forum->update($request->all());
            $forum = Forum::find($id);
            return $this->format->json(true,$forum,'Data berhasil diubah');
        }else{
            return $this->format->json(false,null,'Data tidak ditemukan');
        }
    }

    public function delete($id){
        $forum = Forum::whereId($id);
        if($forum->count() == 1){
            foreach($forum->get() as $item);
                unlink('images/'.$item->image);
            $forum->delete();
            return $this->format->json(true,[],'Data berhasil dihapus');
        }else{
            return $this->format->json(false,null,'Data tidak ditemukan');
        }
    }

}
