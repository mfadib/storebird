<?php 

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Bird;
use App\Libs\Format;
use Validator;

class BirdController extends Controller
{
	private $format;

	public function __construct(Format $format)
	{
		$this->format = $format;
	}
	
	public function view(){
		return $this->format->json(true,Bird::orderBy('updated_at','desc')->get(),'');
	}

	public function detail($id){
		$bird = Bird::whereId($id);
		// return Response()->json($bird);
		if($bird->count() == 1){
			return $this->format->json(true,$bird->get(),'');
		}else{
			return $this->format->json(false,null,'Data tidak ditemukan');
		}
	}

	public function insert(Request $request){
		// return $request->input('image');
		$rules = [
			'title'=>'required',
			'description'=>'required',
			'info'=>'required',
			'price'=>'required',
			'status'=>'required',
			'photo'=>'required'
		];
		$validate = Validator::make($request->all(),$rules);
		if($validate->fails()){
			return $this->format->json(false,null,$validate->errors());
		}else{

            if($request->hasFile('photo')){
                $photo = $request->file('photo');
                $name_file = 'bird-'.time().'-'.str_random(20).'-'.str_slug($request->input('title')).'.'.$photo->getClientOriginalExtension();
                $img = $photo->move('images/',$name_file);
                if($img){
                    $insert = [
                        'title'=>$request->input('title'),
                        'description'=>$request->input('description'),
                        'info'=>$request->input('info'),
                        'price'=>$request->input('price'),
                        'status'=>$request->input('status'),
                        'photo'=>$name_file,
                    ];
                }else{
                    return $this->format->json(false,null,'Gambar gagal diupload');
                }
            }

			// $id = Bird::insertGetId($request->all());
            $id = Bird::insertGetId($insert);
			$bird = $this->format->get_data('birds',['id'=>$id])->get();
			return $this->format->json(true,$bird,'Data berhasil ditambah');
		}
	}

	public function update(Request $request, $id){

		$bird = Bird::whereId($id);
		if($bird->count() == 1){
			$bird->update($request->all());
			$bird = Bird::find($id);
			return $this->format->json(true,$bird,'Data berhasil diubah');
		}else{
			return $this->format->json(false,null,'Data tidak ditemukan');
		}
	}

	public function delete($id){
		$bird = Bird::whereId($id);
		if($bird->count() == 1){
			$bird->delete();
			return $this->format->json(true,[],'Data berhasil dihapus');
		}else{
			return $this->format->json(false,null,'Data tidak ditemukan');
		}
	}

}