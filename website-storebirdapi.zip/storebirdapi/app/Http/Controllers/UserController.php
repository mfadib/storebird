<?php 

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\User;
use App\Libs\Format;
use Validator;

use Auth;

class UserController extends Controller
{
	private $format;

	public function __construct(Format $format)
	{
		$this->format = $format;
	}

	
	public function view(){
		return $this->format->json(true,User::orderBy('updated_at','desc')->get(),'');
	}

	public function detail($id){
		$user = User::whereId($id);
		// return Response()->json($user);
		if($user->count() == 1){
			return $this->format->json(true,$user->get(),'');
		}else{
			return $this->format->json(false,null,'Data tidak ditemukan');
		}
	}

	public function insert(Request $request){
		// $this->middleware('auth:api');
		// return $request->input('image');
		$rules = [
			'name'=>'required',
			'username'=>'required|unique:users,username',
			'email'=>'required|unique:users,email|email',
			'password'=>'required',
			'user_type'=>'required'
		];
		$validate = Validator::make($request->all(),$rules);
		if($validate->fails()){
			return $this->format->json(false,null,$validate->errors());
		}else{
        	$request->merge([
            	'password' 	=> app('hash')->make($request->input('password')),
            	'status'=>1,
            	'api_token'		=> str_random(60)
        	]);
			$id = User::insertGetId($request->all());
			$user = $this->format->get_data('users',['id'=>$id])->get();
			return $this->format->json(true,$user,'Data berhasil ditambah');
		}
	}

	public function update(Request $request, $id){

		$user = User::whereId($id);
		if($user->count() == 1){
			if($request->has('password'))
				$request->merge(['password'=>app('hash')->make($request->input('password'))]);
			if($request->has('api_token'))
				$request->merge(['api_token'=>str_random(60)]);
			$user->update($request->all());
			$user = User::find($id);
			return $this->format->json(true,$user,'Data berhasil diubah');
		}else{
			return $this->format->json(false,null,'Data tidak ditemukan');
		}
	}

	public function delete($id){
		$user = User::whereId($id);
		if($user->count() == 1){
			$user->delete();
			return $this->format->json(true,[],'Data berhasil dihapus');
		}else{
			return $this->format->json(false,null,'Data tidak ditemukan');
		}
	}

	public function login(Request $request)
	{
		$rules = [
			'email'=>'required|email',
			'password'=>'required'
		];
		$validate = Validator::make($request->all(),$rules);
		if($validate->passes()){
			$email = $request->input('email');
			$password = $request->input('password');
			// $remember = ($request->has('remember'))? true : false;
			$check = User::where(['email'=>$email]);
			if($check->count() == 1){
				foreach($check->get() as $item);
				if(app('hash')->check($password,$item->password)){
					// Auth::attempt(['email'=>$request->input('email'),'password'=>$request->input('password')],true);
					return $this->format->json(true,$check->get(),'Selamat datang admin');
				}else{
					return $this->format->json(false,null,'Email atau password salah');
				}
			}else{
				return $this->format->json(false,null,'Email atau password salah');
			}
		}else{
			return $this->format->json(false,null,$validate->errors());
		}
	}

	public function auth_token($api_token)
	{
		$user = User::where(['api_token'=>$api_token]);
		if($user->count() == 1){
			return $this->format->json(true, $user->get(),'');
		}else{
			return $this->format->json(false,null,'Anda tidak memiliki akses ini');
		}
	}

}