<?php
$app->group(['prefix'=>'api/v1/','namespace'=>'App\Http\Controllers'],function() use ($app){
	$app->get('birds', 'BirdController@view');
	$app->get('bird/{id}', 'BirdController@detail');
	$app->post('bird', 'BirdController@insert');
	$app->put('bird/{id}', 'BirdController@update');
	$app->delete('bird/{id}', 'BirdController@delete');

	$app->get('users','UserController@view');
	$app->get('user/{id}', 'UserController@detail');
	$app->post('user', 'UserController@insert');
	$app->put('user/{id}', 'UserController@update');
	$app->delete('user/{id}', 'UserController@delete');

	$app->get('posts', 'PostController@view');
	$app->get('post/{id}', 'PostController@detail');
	$app->post('post', 'PostController@insert');
	$app->put('post/{id}', 'PostController@update');
	$app->delete('post/{id}', 'PostController@delete');

	$app->get('forums', 'ForumController@view');
	$app->get('forum/{id}', 'ForumController@detail');
	$app->post('forum', 'ForumController@insert');
	$app->put('forum/{id}', 'ForumController@update');
	$app->delete('forum/{id}', 'ForumController@delete');

	$app->get('comment/{id}', 'CommentController@comment');
	$app->get('comments/view/{relation_id}/{comment_type}', 'CommentController@relation_comments');
	$app->post('comment', 'CommentController@insert_comment');
	$app->put('comment/{id}', 'CommentController@update_comment');
	$app->delete('comment/{id}', 'CommentController@delete_comment');

	// USER AUTH 
	// 
	

	$app->group(['middleware'=>'auth:api'],function() use ($app){

	});

	$app->post('auth/login','UserController@login');
	$app->get('auth/{api_token}','UserController@auth_token');
});

$app->get('/hello',function(){
	return "Hey";
});
