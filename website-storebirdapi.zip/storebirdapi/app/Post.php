<?php 

namespace App;

use Illuminate\Database\Eloquent\Model;

class Post extends Model
{
	protected $table = 'posts';

	protected $fillable = ['title', 'description','post_type','status','image','created_at','updated_at'];
}