<?php 
namespace app\Libs;

use DB;

class Format
{
	public function json($status, $data, $message){
		return Response()->json(['status'=>$status,'data'=>$data,'message'=>$message]);
	}
	
	public function get_data($table, $where= null,$opt=null){
		$table = DB::table($table);
		if($where != null){
			$table->where($where);
		}

		if(($opt != null) && (is_array($opt))){
			foreach($opt as $key=>$value){
				if(is_array($value)){
					foreach($value as $field=>$val);
					$table->$key($field,$val);
				}else{
					$table->$key($value);
				}
			}
		}

		return $table;
	}

}