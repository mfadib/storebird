<?php 

namespace App;

use Illuminate\Database\Eloquent\Model;

class Bird extends Model
{
	protected $table = 'birds';

	protected $fillable = ['title', 'description','price','info','status','photo','created_at','updated_at'];


}