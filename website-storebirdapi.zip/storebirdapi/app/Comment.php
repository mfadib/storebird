<?php 

namespace App;

use Illuminate\Database\Eloquent\Model;

class Comment extends Model
{
	protected $table = 'comments';

	// protected $fillable = ['user_id','relation_id','comment_type','comment_parent','comment','status','created_at','updated_at'];
	protected $fillable = ['user_id','relation_id','comment_type','comment_parent','comment','status','created_at','updated_at'];

}